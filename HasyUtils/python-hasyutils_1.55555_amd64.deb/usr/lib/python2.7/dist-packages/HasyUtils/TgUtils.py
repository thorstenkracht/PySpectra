#!/usr/bin/env python
# 
# 20.9.2018 
#   - added tags feature '-t'
#     *** note: this is coupled with SardanaAIO
#     consider this case, SardanaMotorMenu is lauchned 
#     with a tag which is more exclusive than the
#     last SardanaAIO command. In this case the SMM 
#     would import the remaining devices via the pool      
#
#
# not fatal because pyspViewer.py might be called on a non-exp host
#
try: 
    import PyTango as _PyTango
except: 
    pass
try: 
    from taurus.core.util.codecs import CodecFactory as _CodecFactory
except:
    pass
import time as _time
import sys as _sys
import os as _os
import types as _types
import socket as _socket
    
import apt as _apt
import json as _json
import signal as _signal
import numpy as np

#
#
#
_dbProxy = None
_petraGlobalsKeyword = None
#
# try to avoid DB I/O, therefore store macroServerProxy
#
_macroServerProxy = None
_doorProxy = None
_versionSardanaString = None
def getVersionSardana():
    '''
    returns the version number of the package
      - old: 2.2.4.9-1+deb8u1~fsec
      - new: 2.4.1.1-1+deb9u4~fsec    
      - Debian-10/Python3 3.0.2.6-1+deb10u1~fsec, 16.6.2020

    see also: HasyUtils.getHostVersionSardana( <hostName>), returns 2 or 3. 

    '''
    global _versionSardanaString
    if _versionSardanaString is None:
        cache = _apt.Cache()
        if 'python-sardana' in cache:
            pkg = cache['python-sardana']
            if not pkg.is_installed: 
                if 'python3-sardana' in cache: 
                    pkg = cache['python3-sardana']
                    if not pkg.is_installed:
                        print( "TgUtils.getVersionSardana: failed to find python*-sardana")
                        _sys.exit( 255)
        _versionSardanaString = pkg.installed.version
    return _versionSardanaString

def getPythonVersionSardana():
    """
    return python2 or python3 depending on the python*-sardana
    """
    vmajor, vminor = [int(ver) for ver in getVersionSardana().split(".")[:2]]

    argout = '/usr/bin/python'
    if vmajor >= 3:
        argout = '/usr/bin/python3'

    return argout

def versionSardanaNewMg():
    '''
    returns True, if the Sardana version has no 'units' level in the
        measurement group. In this case the Pool has the attribute
        TriggerGateList

    analyses the version string, e.g.: 
      - old: 2.2.4.9-1+deb8u1~fsec 
        vs. 
      - new: 2.4.1.1-1+deb9u4~fsec

      - Debian-10/Python3 3.0.2.6-1+deb10u1~fsec' 

    Code:
      vmajor, vminor = [int(ver) for ver in versionSardana().split(".")[:2]]
      if vmajor > 2 or vminor > 3:
          return True
      else:
          return False
    '''
    vmajor, vminor = [int(ver) for ver in getVersionSardana().split(".")[:2]]
    if vmajor > 2 or vminor > 3:
        return True
    else:
        return False
    
def waitForServer( serverName, time_max, tangoHost = None):
    '''
    serverName, e.g.: "OmsVme58/EH" 
    return true, if the server appears in the list of 
    running servers before time_max [s] expires. Limit
    for time_max: 900s
    tangoHost: "haspp99:10000"
    '''
    #
    # first check whether the server is controlled by the starter
    #
    starter = getStarterDevice( serverName, tangoHost)
    if starter is None:
        print( "TgUtils.waitForServer: %s not controlled by Starter" % ( serverName))
        return False

    if time_max > 900:
        print( "TgUtils.waitForServer: time_max %g > max 900" % time_max)
        return False

    startTime = _time.time()
    firstLine = False
    waitTimeBeforePrint = 3
    while 1: 
        if (_time.time() - startTime > waitTimeBeforePrint):
            if _os.isatty(1):
                if not firstLine: 
                    print( "Waiting for %s (max %ds) " % (serverName, time_max), )
                    firstLine = True
                _sys.stdout.write( '.')
                _sys.stdout.flush()
        ret = serverIsRunning( serverName, tangoHost)
        if ret is None: 
            #
            # maybe the Starter is not even active.
            #
            _time.sleep(5)

        if ret:
            if _os.isatty(1):
                if (_time.time() - startTime > waitTimeBeforePrint):
                    print( "")  # because of _sys.stdout.write()
            #
            # if we don't have to wait (sleep) for the server, don't mention the wait-time
            #
            if (_time.time() - startTime) > 1.:
                print( "TgUtils.waitForServer: %s is running after %g s" % ( serverName, _time.time() - startTime))
            return True

        if (_time.time() - startTime) > time_max:
            if _os.isatty(1):
                print( "")
            print( "TgUtils.waitForServer: terminate on time %s" % serverName)
            return False
        
        _time.sleep(1)

    print( "TgUtils.waitForServer: DONE - should never reach this line" )

def serverIsRunning( serverName, tangoHost = None):
    '''
    serverName, e.g.: "OmsVme58/EH" 
    returns True, if the server is in the DevGetRunningServers list
    returns None, if something is really wrong
    tangoHost, e.g.: 'haspp99:10000"
    '''
    try:
        starter = getStarterDevice( serverName, tangoHost)
    except:
        print( "TgUtils.serverIsRunning: failed to get starterDevice\n")
        return None

    if starter is None:
        return False
    
    try:
        starterProxy = _PyTango.DeviceProxy( starter)
    except:
        print( "TgUtils.serverIsRunning: failed to create proxy to starter %s, checking server %s\n" % (starter, serverName))
        return None
    
    try:
        starterProxy.command_inout("UpdateServersInfo")
    except: 
        #
        # just return None silently because we might might for the Starter after reboot
        #
        return None
    try:
        lst = starterProxy.command_inout("DevGetRunningServers", True)
    except: 
        print( "TgUtils.serverIsRunning: command DevGetRunningServers failed on starter %s" % (starter))
        return None

    if serverName in lst: 
        return True
    return False

def serverIsStopped( serverName, tangoHost = None):
    '''
    serverName, e.g.: "OmsVme58/EH" 
    returns True, if the server is in the DevGetRunningServers list
    '''

    starter = getStarterDevice( serverName, tangoHost)
    
    try:
        starterProxy = _PyTango.DeviceProxy( starter)
    except:
        print( "TgUtils.serverisStopped: failed to create proxy to starter %s, checking server %s" % ( starter, serverName))
        return False
    
    try:
        starterProxy.command_inout("UpdateServersInfo")
    except: 
        return False
    lst = starterProxy.command_inout("DevGetStopServers", True)

    if serverName in lst: 
        return True
    return False

def lsMacroServerEnvironment(): 
    '''
    display the MS environment
    '''
    lst = getMacroServerNames()
    tangoHost = _os.environ[ 'TANGO_HOST'].split(':')[0]
    if not lst:
        print( "%s has no MacroServer" % ( tangoHost))
        return
    for elm in lst:
        ms = _PyTango.DeviceProxy( elm)
        dct = _CodecFactory().getCodec('pickle').decode(ms.Environment)[1]['new']
        print( "MacroServer %s %s " % (tangoHost, elm))
        for key in list( dct.keys()):
            a = "%s" % dct[key]
            if len(a) > 60:
                a = a[:60] + " ..."
            print( "%-30s %-8s %s" % ( key, dct[key].__class__.__name__, a))
    return 

def checkMacroServerEnvironment():
    '''
    check whether ScanDir and ScanFile are of type 'str' and
    ScanHistory is of type 'list'
    '''
    lst = getMacroServerNames()
    tangoHost = _os.environ[ 'TANGO_HOST'].split(':')[0]
    if not lst:
        print( "%s has no MacroServer" % ( tangoHost))
        return
    for elm in lst:
        errFlag = False
        ms = _PyTango.DeviceProxy( elm)
        dct = _CodecFactory().getCodec('pickle').decode(ms.Environment)[1]['new']
        for s in ['ScanDir', 'ScanFile']: 
            if s not in dct:
                errFlag = True
                print( "%s %s %s does not exist " % ( tangoHost, elm, s))
                continue
            if not isinstance( dct[ s], _types.StringType):
                errFlag = True
                print( "%s %s %s is of type %s " % ( tangoHost, elm, s, dct[ s].__class__))
        for l in ['ScanHistory']: 
            if l not in dct:
                errFlag = True
                print( "%s %s %s does not exist " % ( tangoHost, elm, l))
                continue
            if not isinstance( dct[ l], _types.ListType):
                errFlag = True
                print( "%s %s %s is of type %s " % ( tangoHost, elm, l, dct[ l].__class__))
        if not errFlag:
            print( "%s %s: ScanDir, ScanFile and ScanHistory are ok" % ( tangoHost, elm))

def tellBLStaff( errorMsgs, addrList):
    '''
    send the joint errorMsgs list to all recipients of addrList

    e.g.
      HasyUtils.tellBLStaff( ["back to work", "petra delivering beam"], 
                             ["some.name@desy.de", "another.name@desy.de"])
    '''
    if( len( errorMsgs) == 0 or 
        len( addrList) == 0):
            return
        
    for addr in addrList:
        if addr.find( "sms") >= 0:
            _os.system( "echo \"%s\" | mail %s" % ("\n".join( errorMsgs), addr))
        else:
            _os.system( "echo \"%s\" | mail -s ECMonitor %s" % ("\n".join( errorMsgs), addr))
    
def checkMacroServer( flagSingle, errorMsgs):
    '''
    check whether the local MacroServer is up and running.
    Otherwise error messages are appended to errorMsgs

    called from ECMonitor.py

    flagSingle == False
      the function is called from within a loop, e.g. waiting for some condition
      and tell the BL scientist when it occurs

    flagSingle == True
      the function is NOT called from within a loop; some logging is produced.

    errorMsgs: list, to be appended with error msgs

    returns True, if all local MS as up and running
    '''
    msList = getLocalMacroServerNames()
    if len(msList) == 0:
        errorMsgs.append( "No MacroServer in DB")
        return
    state = None
    argout = True
    for ms in msList:
        if flagSingle: print( "MacroServer: %s" % ms)
        try:
            p = _PyTango.DeviceProxy( ms)
        except:
            argout = False
            errorMsgs.append( "MacroServer %s is offline")
            continue
        try:
            state = p.state()
        except _PyTango.DevFailed:
            argout = False
            extype, value = _sys.exc_info()[:2]
            if extype == _PyTango.ConnectionFailed:
                errorMsgs.append( "MacroServer %s not exported" % (ms))
            else:
                errorMsgs.append( "CheckMacroServer: failed with exception %s" % (extype))
                for err in value:
                    errorMsgs.append( " reason %s" % err.reason)
                    errorMsgs.append( " desc %s " % err.desc)
                    errorMsgs.append( " origin %s " % err.origin)
                    errorMsgs.append( " severity %s " % err.severity)
            continue
    return argout

def checkPool( flagSingle, errorMsgs):
    '''
    check whether the local Pool is up and running.
    Otherwise error messages are appended to errorMsgs

    called from ECMonitor.py

    flagSingle == False
      the function is called from within a loop, e.g. waiting for some condition
      and tell the BL scientist when it occurs

    flagSingle == True
      the function is NOT called from within a loop; some logging is produced.
    
    errorMsgs: list, to be appended with error msgs

    returns True, if all local MS as up and running
    '''
    plList = getLocalPoolNames()
    if len(plList) == 0:
        errorMsgs.append( "No Pool in DB")
        return
    state = None
    argout = True
    for pl in plList:
        if flagSingle: print( "Pool: %s" % pl)
        try:
            p = _PyTango.DeviceProxy( pl)
        except:
            errorMsgs.append( "Pool %s is offline" % pl)
            argout = False
            continue
        try:
            state = p.state()
        except _PyTango.DevFailed:
            argout = False
            extype, value = _sys.exc_info()[:2]
            if extype == _PyTango.ConnectionFailed:
                errorMsgs.append( "Pool %s not exported" % (pl))
            else:
                errorMsgs.append( "CheckPool: %s Failed with exception %s" % (pl, extype))
                for err in value:
                    errorMsgs.append( " reason %s" % err.reason)
                    errorMsgs.append( " desc %s " % err.desc)
                    errorMsgs.append( " origin %s " % err.origin)
                    errorMsgs.append( " severity %s " % err.severity)
            continue
    return argout

def checkZMX( flagSingle, errorMsgs):
    '''
    check the ZMXs on the local TANGO_HOST and all TANGO_HOSTs
    mentioned in online.xml. Complain about everything except 
    'no error' and 'Unknown'.

    called from ECMonitor.py

    flagSingle == False
      the function is called from within a loop, e.g. waiting for some condition
      and tell the BL scientist when it occurs

    flagSingle == True
      the function is NOT called from within a loop; some logging is produced.

    errorMsgs: list, to be appended with error msgs

    returns True, if all local MS as up and running

    '''
    hostList = []
    hostList.append( _os.environ[ 'TANGO_HOST'].split(':')[0])
    hshList = getOnlineXML()
    #
    # find the TANGO_HOSTs mentioned in online.xml
    #
    for hsh in hshList:
        if "hostname" not in hsh:
            continue
        hst = hsh[ 'hostname'].split(':')[0]
        if hst not in hostList:
            hostList.append( hst)

    argout = True
    for hst in hostList:
        zmxList = getDeviceNamesByClass( "ZMX", hst)
        for zmx in zmxList:
            devName = "%s:10000/%s" % ( hst, zmx)
            if flagSingle: print( " devName %s" % devName)
            try: 
                p = _PyTango.DeviceProxy(devName)
                if( p.read_attribute( 'Error').value != 'no error' and
                    p.read_attribute( 'Error').value != 'Unknown'): 
                    errorMsgs.append( "%s/Error %s returns %s, axis %s" % 
                                      (zmx, hst, p.read_attribute( 'Error').value,
                                       p.read_attribute( 'AxisName').value))
            except _PyTango.DevFailed:
                argout = False
                extype, value = _sys.exc_info()[:2]
                if flagSingle: print( "Failed with exception %s %s" % (devName, extype))
                errorMsgs.append( "Failed with exception %s %s" % (devName, extype))
    return argout

def getClassList( tangoHost = None):
    '''
    Return list containing all classes, e.g.
    getClassList()
    getClassList( "haspp99:10000")
    '''
    
    db = _findDB( tangoHost)
    if not db:
        return None

    return db.get_class_list( "*").value_string

def getHostList( tangoHost = None):
    '''Return all host names in the local or remote TangoDb'''

    db = _findDB( tangoHost)
    if not db:
        return None

    tempList = db.get_host_list( "*").value_string
    hostList = []
    for hst in tempList:
        if hst.find( '.') > 0:
            hst = hst.split( '.')[0]
        if hst == 'nada':
            continue
        if not hst in hostList:
            hostList.append( hst)

    return hostList

def getHostname():
    '''Return the hostname, short form, e.g.: haspp08 '''
    return _socket.gethostname()

def getHostnameLong():
    '''return the hostname, long form, e.g.: haspp08.desy.de '''
    # ('haso107tk.desy.de', ['haso107tk'], ['131.169.221.161'])
    return _socket.gethostbyname_ex( _socket.gethostname())[0]

def getAlias( deviceName, tangoHost = None):
    '''    
    getAlias( "p99/motor/exp.99")
    getAlias(  "p99/motor/exp.99", "haspp99:10000")
    '''    
    db = _findDB( tangoHost)
    if not db:
        return None

    argout = "NoAlias"
    try:
        argout = db.get_alias( deviceName)
    except:
        pass
    return argout


def getDeviceNameByAlias( alias, tangoHost = None):
    '''
    Return the tango device which is referred to by an alias 
    e.g.: getDeviceNameBYAlias( "exp_mot99") 

    tangoHost e.g.: "haspp99:10000"
    '''
    argout = None
    
    db = _findDB( tangoHost)
    if not db:
        return None
    
    try:
        argout = db.get_device_alias( alias)
    except Exception as e:
        print( "TgUtils.getDeviceNameByAlias: alias: %s" % repr( alias))
        print( "TgUtils.getDeviceNameByAlias: %s" % repr( e))

    return argout

def _findDB( tangoHost = None):
    '''
    handle these cases:
      - tangoHost == None: use TANGO_HOST DB
      - tangoHost == "haspp99:10000" return db link
      - tangoHost == "haspp99" insert 100000 and return db link
    '''
    if tangoHost is None:
        return _db

    #
    # unexpeccted: tango://haspe212oh.desy.de:10000/motor/dummy_mot_ctrl/1
    #
    if tangoHost.find( 'tango://') == 0:
        print( "TgUtils._fineDB: bad TANGO_HOST syntax %s" % tangoHost)
        return None
    #
    # tangHost "haspp99:10000"
    #
    lst = tangoHost.split( ':')
    if len(lst) == 2:
        return _PyTango.Database( lst[0], lst[1])
    #
    # tangHost "haspp99"
    #
    elif len(lst) == 1:
        return _PyTango.Database( lst[0], "10000")
    else:
        return None

def getDeviceNamesByServer( serverName, tangoHost = None):
    '''
    Return the devices belonging to a server. If tangoHost is
    not supplied, TANGO_HOST is used.

      getDeviceNamesByServer( "DGG2/PETRA-3", "haspp99:10000")
        ['p99/dgg2/exp.01', 'p99/dgg2/exp.01'] 

      getDeviceNamesByServer( "DGG2/PETRA-3")
        ['p99/dgg2/exp.01', 'p99/dgg2/exp.01'] 
    '''

    db = _findDB( tangoHost)
    if not db:
        return None
    #
    # ['dserver/DGG2/PETRA-3', 'DServer', 'p09/dgg2/d1.01', 'DGG2', 'p09/dgg2/d1.02', 'DGG2']
    #
    lst = db.get_device_class_list( serverName).value_string
    if not lst:
        return None
    def pairs( lst):
        a = iter(lst)
        return list( zip( a, a))

    devList = []
    for deviceName, className in pairs( lst):
        if className == "DServer":
            continue
        devList.append( deviceName)
    return devList
    
def getDeviceNamesByClass( className, tangoHost = None):
    '''Return a list of all devices of a specified class, 
        'DGG2' -> ['p09/dgg2/exp.01', 'p09/dgg2/exp.02']
    '''
    srvs = getServerNameByClass( className, tangoHost)
    argout = []
    
    db = _findDB( tangoHost)
    if not db:
        return None

    for srv in srvs:
        lst = db.get_device_name( srv, className).value_string
        for i in range(0, len( lst)):
            argout.append( lst[i])
    return argout

def getMotorNames():
    '''
    get device names of motor classes:
    '''
    motorClassList = [
        "AbsorberController", 
        "Analyzer", 
        "AnalyzerEP01", 
        "AttoCube", 
        "AttoCubeANC300", 
        "AttributeMotor", 
        "CDCMEnergy", 
        "CoupledMonoUndMove", 
        "CubicPressVoggMotor", 
        "CubicPressCylinder", 
        "DiffracMuP09", 
        "DOOCSMotor", 
        "EcovarioServoMotor", 
        "EH2tthP10", 
        "FMBOxfDCMEnergy", 
        "FMBOxfDCMMotor", 
        "FocusingMirrorP02", 
        "GalilDMCMotor", 
        "GalilDMCSlit", 
        "HexapodMotor", 
        "HiResPostMonoP22", 
        "KohzuSCAxis", 
        "KohzuSCMultiAxis", 
        "LensesBox", 
        "LOM", 
        "LomEnergy", 
        "Lom500Energy", 
        "MetaMotor", 
        "MirrorP02", 
        "MirrorP09", 
        "MLMonoEnergy", 
        "MMC100MicosAxis", 
        "MonoP04", 
        "MonoUndSynchronMotor", 
        "MotorEncControlledP04", 
        "MultipleMotors", 
        "NewFocusPicoMotor", 
        "NewFocusPico8742", 
        "OmsVme58", 
        "OwisMMS19", 
        "PhaseRetarderP09", 
        "PIC863Mercury", 
        "PhyMotionMotor", 
        "PiezoJenaNV401CLE", 
        "PiezoPiE185", 
        "PiezoPiE710", 
        "PiezoPiE712", 
        "PiezoPiE725", 
        "PiezoPiE816", 
        "PiezoPiE861", 
        "PiezoPiE871", 
        "PiezoPiE872", 
        "PiezoPiC867Motor", 
        "PitchRollCorrection", 
        "PlcUndulator", 
        "SecondaryMonoP01", 
        "SMCHydraMotor", 
        "Slt", 
        "Spk", 
        "TangoMotor", 
        "TcpIpMotorP10", 
        "TwoThetaP07", 
        "VICIMultiPosValve", 
        "VICITwoPosValve", 
        "VmExecutor"]

    motorList = []
    for motorClass in motorClassList:
        motorList.extend( getDeviceNamesByClass( motorClass))
    return motorList

def getServerInstance( argin, tangoHost = None): 
    '''
    Return a list of Server instances matching the supplied server name.
    argin, e.g. "OmsVme58" result: ["EH"]
    tangoHost e.g.: "haspp99:10000"
    '''
    
    db = _findDB( tangoHost)
    if not db:
        return None

    lst =  db.get_server_list( "*").value_string
    argout = []
    for elm in lst:
        if elm.find( argin) >= 0:           
            argout.append(elm.split("/")[1])
    return argout
        
def getServerNameByClass( argin, tangoHost = None): 
    '''Return a list of servers containing the specified class '''

    db = _findDB( tangoHost)

    srvs = db.get_server_list( "*").value_string

    argout = []

    for srv in srvs:
        classList = db.get_server_class_list( srv).value_string
        for clss in classList:
            if clss == argin:
                argout.append( srv)
                break
    return argout

def getServerNameByDevice( devName, tangoHost = None): 
    """
    return the server exporting a device, devName: 'p99/motor/eh.01'
    """
    db = _findDB( tangoHost)

    ret = db.get_device_info( devName)

    return ret.ds_full_name
    
def _getLocalNames( namesList):
    '''Receive  a list of devices and return those devices running locally.'''
    lst_out = []
    hostName = getHostname()
    
    for d in namesList:
        try:
            devInfo = _dbProxy.DbGetDeviceInfo( d)
        except Exception as e:
            print( "---")
            print( "TgUtils._getLocalName: can't get DeviceInfo for %s" % d)
            print( "TgUtils._getLocalName: Is the DB server running?")
            print( _sys.exc_info()[0])
            print( repr( e))
            print( "---")
            continue
            
        srvHost = devInfo[1][4].split('.')[0]
        if srvHost == hostName:
            lst_out.append( d)
    return lst_out

def getDoorNames():
    '''Return a list of Door tango devices.'''
    return getDeviceNamesByClass( "Door")

def getLocalDoorNames():
    '''Return a list of Door tango devices running locally.'''
    return _getLocalNames( getDeviceNamesByClass( "Door"))

def getMacroServerNames():
    '''Return a list of MacroServer tango devices.'''
    return getDeviceNamesByClass( "MacroServer")

def getLocalMacroServerNames():
    '''Return a list of MacroServer tango devices running locally.'''
    return _getLocalNames( getDeviceNamesByClass( "MacroServer"))

def getLocalMacroServerServers():
    '''Return a list of local MacroServers, e.g.: MacroServer/PETRA-3 '''
    lst = _db.get_server_list("MacroServer*")
    hostName = getHostname()
    argout = []
    for srv in lst:
        a = _db.get_server_info( srv)
        if a.host.split('.')[0] == hostName:
            argout.append(srv)
    return argout

def getMacroInfo( macroName): 
    '''
    returns a dictionary
    '''
    lst = getMacroServerNames()
    if len( lst) != 1: 
        raise ValueError( "TgUtils.getMacroInfo: no. of MacroServers %d != 1" % len( lst))
    try: 
        p = _PyTango.DeviceProxy( lst[0])
    except Exception as e: 
        print( "TgUtils.getMacroInfo: error, %s" % repr( e))
        return None
    ret = p.command_inout("GetMacroinfo", [macroName])

    argout = _json.loads( ret[0])

    if argout[ 'name'] != macroName: 
        raise ValueError( "TgUtils.getMacroInfo: received %s" % repr( argout))

    return argout

def getMacroServerServers():
    argout = _db.get_server_list("MacroServer*")
    return argout

def getPoolServers():
    argout = _db.get_server_list("Pool*")
    return argout

def runMacro( macroString):
    '''
    macroString: "ascan exp_dmy01 0 1 10 0.1"
    
    the macro is started on getDoorNames()[0]
    the function waits for the completion

    return: door.output
    '''
    lst = macroString.split( " ")
    try:
        door = _PyTango.DeviceProxy( getDoorNames()[0])
    except: 
        return "No door"
    door.runMacro( lst)
    while door.state() is _PyTango.DevState.RUNNING:
        _time.sleep( 0.1)
    return door.output

def startMacro( macroString):
    '''
    macroString: "ascan exp_dmy01 0 1 10 0.1"
    
    the macro is started on getDoorNames()[0]
    the function does not wait for completion 
    '''
    lst = macroString.split( " ")
    try:
        door = _PyTango.DeviceProxy( getDoorNames()[0])
    except: 
        return "No door"
    door.runMacro( lst)
    return 
    
def getMacroServerStatusInfo():
    '''
    this code is also in PySpectra.utils

    parses the MacroServer status() information; to be printed in a Label Widget

    returns e.g.:
      - "Idle"
      - "ascan"
      - "IVPmacro -> change_mg"
    '''
    global _doorProxy
    #
    # in case the macroserver is IDLE: 
    # macroStatusLst ['The device is in ON state.', 
    #                 ' Macro stack ([state] macro):', 
    #                 '    -[finish]\tIVPmacro mg']
    # 
    # macroStatusLst ['The device is in RUNNING state.', 
    #                 ' Macro stack ([state] macro):', 
    #                 '    -[start]\tIVPmacro mg', 
    #                 "    -[start]\tchange_mg [['-g', 'mg_ivptest'], ['-t', 'd1_t01'], ['-c', 'd1_c01,d1_c02']]"]
    #
    if _doorProxy is None:
        try:
            _doorProxy = _PyTango.DeviceProxy( getDoorNames()[0])
        except: 
            return "No door"

    macroStatusLst = _doorProxy.status().split( "\n")
    if macroStatusLst[0] == 'The device is in ON state.':
        argout = "Idle"
        return argout
    try:
        a = ""
        for elm in macroStatusLst[2:]:
            lst = elm.split("\t")
            lst1 = lst[1].split( " ")
            a = a + lst1[0] + '->'
    except: 
        a = "unknown ->" 
    #
    # cut the trailing '->'
    #
    argout = a[:-2]
    return argout


def getPoolNames():
    '''Return a list of Pool tango devices.'''
    return getDeviceNamesByClass( "Pool")

def getLocalPoolNames():
    '''Return a list of Pool tango devices running locally.'''
    return _getLocalNames( getDeviceNamesByClass( "Pool"))

def getLocalPoolServers():
    '''Return a list of local Pool server names, e.g.: ['Pool/haspp02ch2']'''
    lst = _db.get_server_list("Pool*")
    hostName = getHostname()
    argout = []
    for srv in lst:
        a = _db.get_server_info( srv)
        if a.host.split('.')[0] == hostName:
            argout.append(srv)
    return argout

def getMgAliases():
    '''Return the list of MeasurementGroup aliases, e.g. ['mg_haso107klx'] '''
    lst = getDeviceNamesByClass( "MeasurementGroup")
    if not lst:
        return None
    argout = []
    for elm in lst:
        argout.append( _db.get_alias( elm))
    return argout

def getMgElements( mgName):
    ''' Return the list of elements (aka devices) belonging to an Mg'''
    try:
        p = _PyTango.DeviceProxy( mgName)
    except: 
        print( "TgUtils.getMgElements: proxy to %s failed" % mgName)
        return None
    return list(p.ElementList)

def getLocalMgNames():
    '''Return the list of MeasurementGroup device names running locally.'''
    return _getLocalNames( getDeviceNamesByClass( "MeasurementGroup"))

def getLocalMgAliases():
    '''Return the list of MeasurementGroup aliases running locally.'''
    lst = _getLocalNames( getDeviceNamesByClass( "MeasurementGroup"))
    if not lst:
        return None
    argout = []
    for elm in lst:
        argout.append( _db.get_alias( elm))
    return argout


def getActiveMntGrpStatus():
    '''
    Returns a list of strings containing the status info of the
    ActiveMntGrp and their elements. If this list is not empty, 
    it contains strings describing the problems.
    To be called, if checkActiveMntGrpStatus() returns False
    '''
    activeMntGrp = getEnv( "ActiveMntGrp")
    argout = []
    if activeMntGrp is None:
        argout.append( "no ActiveMntGrp")
        return argout
    try:
        p = _PyTango.DeviceProxy( activeMntGrp)
    except Exception as e:
        argout.append( "failed to create proxy to %s" %activeMntGrp)
        return argout

    if p.state() == _PyTango.DevState.FAULT:
        argout.append( "%s is in FAULT state" % activeMntGrp )

    if p.state() == _PyTango.DevState.ALARM:
        argout.append( "%s is in ALARM state" % activeMntGrp )
        
    lst = getMgElements( activeMntGrp)
    for elm in lst:
        try:
            p = _PyTango.DeviceProxy( elm)
        except Exception as e:
            argout.append( "failed to create proxy to %s" % elm)
            continue
        if p.state() == _PyTango.DevState.FAULT:
            argout.append( "%s is in FAULT state" % elm)
            continue
        if p.state() == _PyTango.DevState.ALARM:
            argout.append( "%s is in ALARM state" % elm)
            continue
        #
        # no point in looking at 
        #  - Counts or Value because if the server is off, hasattr( p, "Counts") returns False
        #  - TangoDevice because there are controller devices without TangoDevice, e.g. h, k, l

    return argout

def checkActiveMntGrpStatus():
    '''
    calls getActiveMntGrpStatus() which returns a list.
    returns True, if this list is empty, meaning no bad messages
    '''
    lst = getActiveMntGrpStatus()
    if len( lst) == 0:
        return True
    else:
        return False


def devState2String( state): 
    '''
    PyTango.DevState.ALARM -> "ALARM"
    '''
    if state == _PyTango.DevState.ALARM: 
        argout = "ALARM"
    elif state == _PyTango.DevState.CLOSE: 
        argout = "CLOSE"
    elif state == _PyTango.DevState.DISABLE: 
        argout = "DISABLE"
    elif state == _PyTango.DevState.EXTRACT: 
        argout = "EXTRACT"
    elif state == _PyTango.DevState.FAULT: 
        argout = "FAULT"
    elif state == _PyTango.DevState.INIT: 
        argout = "INIT"
    elif state == _PyTango.DevState.INSERT: 
        argout = "INSERT"
    elif state == _PyTango.DevState.MOVING: 
        argout = "MOVING"
    elif state == _PyTango.DevState.OFF: 
        argout = "OFF"
    elif state == _PyTango.DevState.ON: 
        argout = "ON"
    elif state == _PyTango.DevState.OPEN: 
        argout = "OPEN"
    elif state == _PyTango.DevState.RUNNING: 
        argout = "RUNNING"
    elif state == _PyTango.DevState.STANDBY: 
        argout = "STANDBY"
    elif state == _PyTango.DevState.UNKNOWN: 
        argout = "UNKNOWN"
    else:
        argout = "REALLY_UNKNOWN"
    return argout

def returnActiveMntGrpStatus():
    '''
    calls getActiveMntGrpStatus() which returns a list.
    returns True, if this list is empty, meaning no bad messages
    '''
    activeMntGrp = getEnv( "ActiveMntGrp")
    argout = []
    if activeMntGrp is None:
        argout.append( "no ActiveMntGrp")
        return argout
    try:
        p = _PyTango.DeviceProxy( activeMntGrp)
    except Exception as e:
        argout.append( "failed to create proxy to %s" %activeMntGrp)
        return argout

    argout.append( "%s is in %s state" % (activeMntGrp, devState2String( p.state())) )
        
    lst = getMgElements( activeMntGrp)
    for elm in lst:
        try:
            p = _PyTango.DeviceProxy( elm)
        except Exception as e:
            argout.append( "failed to create proxy to %s" % elm)
            continue
        argout.append( "%s is in %s state" % (elm, devState2String( p.state())))

    return argout
    
def getTimerAliases():
    '''Return the list of Timer aliases'''
    lst = getDeviceNamesByClass( "CTExpChannel")
    if not lst:
        return None
    argout = []
    for elm in lst:
        if elm.find( 'dgg2') == -1:
            continue
        argout.append( _db.get_alias( elm))
    return argout

def getCounterAliases():
    '''Return the list of Counter aliases'''
    lst = getDeviceNamesByClass( "CTExpChannel")
    if not lst:
        return None
    argout = []
    for elm in lst:
        if elm.find( 'sis3820') == -1:
            continue
        argout.append( _db.get_alias( elm))
    return argout

def getVfcAdcAliases():
    '''Return the list of Counter aliases'''
    lst = getDeviceNamesByClass( "CTExpChannel")
    if not lst:
        return None
    argout = []
    for elm in lst:
        if elm.find( 'vfcadc') == -1:
            continue
        argout.append( _db.get_alias( elm))
    return argout

def getAdcAliases():
    '''Return the list of ADC aliases'''
    lst = getDeviceNamesByClass( "ZeroDExpChannel")
    if not lst:
        return None
    argout = []
    for elm in lst:
        if elm.find( 'tip830') == -1:
            continue
        argout.append( _db.get_alias( elm))
    return argout

def getMcaAliases():
    '''Return the list of Counter aliases'''
    lst = getDeviceNamesByClass( "OneDExpChannel")
    if not lst:
        return None
    argout = []
    for elm in lst:
        if elm.find( 'mca8701') == -1:
            continue
        argout.append( _db.get_alias( elm))
    return argout

def getStarterHostByDevice( device): 
    '''
    return the starter host for a device
    
    HasyUtils.getStarterHostByDevice( "p99/motor/eh.01")
    HasyUtils.getStarterHostByDevice( "haspp99:10000/p99/motor/eh.01")

    '''

    try: 
        p = _PyTango.DeviceProxy( device)
    except Exception as e: 
        print( "TgUtils.getStarterHostByDevice: failed to create proxy")
        print( "%s" % repr( e))
        return None

    return p.info().server_host

def getPoolMotors( poolName):
    ''' 
    Input:  poolName, e.g. p15/pool/haspp15

    Output: a list of full device names of pool motors, e.g.
            ['haspp67:10000/motor/omsvme58_exp/48',...]  
    '''

    try: 
        p = _PyTango.DeviceProxy( poolName)
    except:
        print( "TgUtils.getPoolMotors: failed to connect to poolName")
        return None

    lst = []
    for elm in p.MotorList:
        hsh = _json.loads( elm)
        #
        # haso107d1:10000/motor/omsvme58_d1/48"
        #
        lst.append( hsh['full_name'])

    return lst

def findPoolForMg( mgName):
    '''Return the Pool device name containing mgName.'''
    poolList = getPoolNames()
    for pool in poolList:
        try:
            proxy = _PyTango.DeviceProxy( pool)
        except: 
            continue
        mgList = proxy.MeasurementGroupList
        if not mgList:
            continue
        for elm in mgList:
            dct = _json.loads( elm)
            if mgName == dct['name']:
                return proxy.name()
    return None

def isDevice( devName):
    '''
    returns True, if the device exists 

    Code: 
      try: 
          _PyTango.DeviceProxy( devName)
          return True
      except:
          return False
    '''
    try: 
        _PyTango.DeviceProxy( devName)
        return True
    except:
        return False


def getLocalNXSelectorNames():
    '''Return the list of NXSelector device names running locally.'''
    return _getLocalNames( getDeviceNamesByClass( "NXSRecSelector"))

def getOnlineXML( xmlFile = None, cliTags = None):
    '''
    Read /online_dir/online.xml or a file of that syntax 
    and return a list of dictionaries representing the devices

    cliTags, e.g.: ['user,expert'], is a string like "standard,pilatus" most likely provided on the command line. 
    If supplied, devices have to have tags that match
    '''
    #
    #[..., {
    # {'channel': '72',
    #  'control': 'tango',
    #  'controller': 'oms58_d1',
    #  'device': 'p09/motor/d1.72',
    #  'hostname': 'haso107d1:10000',
    #  'module': 'oms58',
    #  'name': 'd1_mot72',
    #  'rootdevicename': 'p09/motor/d1',
    #  'tags': 'expert,user',
    #  'type': 'stepping_motor'}]
    #

    from lxml import etree

    xmlFileLocal = '/online_dir/online.xml'    
    if xmlFile:
        xmlFileLocal = xmlFile

    if not _os.path.exists( xmlFileLocal):
        return None

    parser = etree.XMLParser( ns_clean=True, remove_comments=True)
    try:
        tree = etree.parse( xmlFileLocal, parser)
    except Exception as e:
        print( "---")
        print( "TgUtils.getOnlineXML: error parsing %s" % xmlFileLocal)
        print( _sys.exc_info()[0])
        print( e)
        print( "---")
        return None

    if cliTags:
        if type( cliTags) is list: 
            lstCliTags = cliTags
        else: 
            lstCliTags = cliTags.split( ',')
        lstCliTags = [ elm.strip() for elm in lstCliTags]
    else:
        lstCliTags = None

    if lstCliTags is not None: 
        print( "TgUtils.getOnline.XML: keep devices and MGs only, if they match these CLI tags %s" % repr( lstCliTags))

    root = tree.getroot()
    devList = []
    for dev in root:
        hsh = {}
        for elm in dev:
            #
            # not so clear whether lower() is needed
            #
            try:
                if elm.tag == "pseudomotor":
                    hsh[ elm.tag] = elm.text
                else:
                    hsh[ elm.tag] = elm.text.lower()
            except Exception as e:
                print( "---")
                print( "TgUtils.getOnlineXML: error processing %s in %s" % (repr( elm), repr( hsh)))
                print( _sys.exc_info()[0])
                print( e)
                print( "---")
                return None
        
        #
        # if no cliTags are supplied, select the device
        #
        if lstCliTags is None:
            devList.append( hsh)        
        else:
            #
            # if the device has to tags field, ignore it
            #
            if "tags" not in hsh:
                continue
            devTags = hsh[ 'tags'].split( ',')
            #
            # if at least one device-tag matches a cli-tag keep it
            #
            flagKeep = False
            for cliTag in lstCliTags:
                for devTag in devTags:
                    if cliTag.strip().lower() == devTag.strip().lower():
                        flagKeep = True
            if flagKeep:
                devList.append( hsh)        
                print( "TgUtils.getOnlineXML: tag-match    %s, %s vs. %s" % (hsh['name'], hsh[ 'tags'], str( lstCliTags)))
            else:
                print( "TgUtils.getOnlineXML: tag-mismatch %s, %s vs. %s" % (hsh['name'], hsh[ 'tags'], str( lstCliTags)))
                pass
        #print( "TgUtils.getOnlineXML: %s" % (repr( hsh)))

    return devList

#
# Door-MacroServer-Pool
#
class DMSP:
    '''Class to access the pool and macroserver being behind a Door '''
    def __init__( self, doorname = None):
        if not doorname:
            _PyTango.Except.throw_exception( "n.n.",
                                            "no doorname supplied",
                                            "TgUtils.DMSP") 
        try:
            self.door = _PyTango.DeviceProxy( doorname)
        except _PyTango.DevFailed as e:
            _PyTango.Except.re_throw_exception( e, 
                                               "from DeviceProxy",
                                               "failed to create proxy to door %s " % doorname,
                                               "TgUtils.DMSP") 
        dct = _db.get_device_property( doorname, ["MacroServerName"])
        macroservername = dct['MacroServerName'][0]
        try:
            self.macroserver = _PyTango.DeviceProxy( macroservername)
        except _PyTango.DevFailed as e:
            _PyTango.Except.re_throw_exception( e, 
                                               "from DeviceProxy", 
                                               "failed to create proxy to macroserver %s " % macroservername,
                                               "TgUtils.DMSP")

        dct = _db.get_device_property( macroservername, ["PoolNames"])
        poolnames = dct['PoolNames']
        self.pools = []
        self.poolNames = []
        for poolname in poolnames:
            try:
                pool = _PyTango.DeviceProxy( poolname)
                self.poolNames.append( poolname)
                self.pools.append( pool)
            except _PyTango.DevFailed as e:
                _PyTango.Except.re_throw_exception( e, 
                                                   "from DeviceProxy", 
                                                   "failed to create proxy to pool %s " % poolname,
                                                   "TgUtils.DMSP")

    #
    #
    #
    def getEnv( self, varName):
        '''Return  the value of an environment variable.'''
        import pickle as _pickle
        dct = _pickle.loads( self.macroserver.environment[1])['new']
        if varName not in dct:
            _PyTango.Except.throw_exception( "TgUtils.DMSP.getEnv", 
                                            "Environment lookup failed",
                                            "missing %s " % varName)
        return dct[varName]
    #
    #
    #
    def setEnv( self, varName, varValue):
        '''Set an environment variable.'''
        value = _CodecFactory().getCodec( 'pickle').decode( self.macroserver.Environment)
        dct = value[1]['new']
        dct[varName] = varValue
        new_value = _CodecFactory().getCodec('pickle').encode(('', dict( new=dct)))
        self.macroserver.write_attribute( 'Environment', new_value)
    #
    #
    #
    def unsetEnv( self, varName):
        '''Un-set an environment variable.'''
        self.door.runmacro(['usenv', varName])

_print_level = 0

def dct_print( d):
    '''
    Prints a dictionary to stdout, e.g. the configuration of the mgGroup.
    '''
    global _print_level
    if len( list( d.keys())) == 0:
        _print_level = _print_level - 2
        return

    lst = list( d.keys())
    lst.sort()
    
    print( "%s{" % ( " " * _print_level))
    _print_level  = _print_level + 2

    for key in lst:
        if type(d[key]) == dict:
            print( "%su'%s': " % (" " * _print_level, key))
            _print_level  = _print_level + 2
            dct_print(d[key])
            continue
        print( " " * _print_level, )
        if type(key) == str:
            print( "u'%s':" % key,)
        else:
            print( "%s:" % key,)
        if type(d[key]).__name__ == 'str':
            print( "'%s'," % d[key])
        elif type(d[key]).__name__ == 'unicode':
            print( "u'%s'," % d[key])
        elif type(d[key]).__name__ == 'int':
            print( "%s," % d[key])
        elif type(d[key]).__name__ == 'float':
            print( "%s," % d[key])
        elif type(d[key]).__name__ == 'bool':
            print( "%s," % d[key])
        elif type(d[key]).__name__ == 'list':
            print( "%s," % d[key])
        elif type(d[key]).__name__ == 'NoneType':
            print( "u'',")
        else:
            print( "%s," % type(d[key]))
    _print_level = _print_level - 2
    if _print_level > 0:
        print( "%s}," % (" " * _print_level))
    else:
        print( "%s}" % (" " * _print_level))
    _print_level = _print_level - 2

    return 

_print_level2str = 0

def dct_print2str( d):
    '''
    converts a dictionary into a string which is returned
    '''
    global _print_level2str

    argout = ""

    if len( list( d.keys())) == 0:
        _print_level2str = _print_level2str - 2
        return None

    lst = list( d.keys())
    lst.sort()
    
    argout += "%s{\n" % ( " " * _print_level2str)
    _print_level2str  = _print_level2str + 2

    for key in lst:
        if type(d[key]) == dict:
            argout +=  "%su'%s': \n" % (" " * _print_level2str, key)
            _print_level2str  = _print_level2str + 2
            ret = dct_print2str(d[key])
            if ret is not None:
                argout += ret
            continue
        argout += " " * _print_level2str
        if type(key) == str:
            argout +=  "'%s':" % key
        else:
            argout +=  "%s:" % key
        if type(d[key]).__name__ == 'str':
            argout +=  "'%s',\n" % d[key]
        elif type(d[key]).__name__ == 'unicode':
            argout +=  "u'%s',\n" % d[key]
        elif type(d[key]).__name__ == 'int':
            argout += "%s,\n" % d[key]
        elif type(d[key]).__name__ == 'float':
            argout += "%s,\n" % d[key]
        elif type(d[key]).__name__ == 'bool':
            argout += "%s,\n" % d[key]
        elif type(d[key]).__name__ == 'list':
            argout += "%s,\n" % d[key]
        elif type(d[key]).__name__ == 'NoneType':
            argout += "u'',\n"
        else:
            argout += "%s,\n" % type(d[key])
    _print_level2str = _print_level2str - 2
    if _print_level2str > 0:
        argout += "%s},\n" % (" " * _print_level2str)
    else:
        argout += "%s}\n" % (" " * _print_level2str)
    _print_level2str = _print_level2str - 2

    return argout

_initInkey = False
_initInkeyOldTermAttr = None

def _inkeyExitHandler(): 
    global _initInkey
    global _initInkeyOldTermAttr
    import termios as _termios

    if not _initInkey:
        return
    _initInkey = False
    _termios.tcsetattr( _sys.stdin.fileno(), _termios.TCSADRAIN, _initInkeyOldTermAttr)
    return

def inkey( resetTerminal = None):
    '''
    Return the pressed key, nonblocking. Returns -1, if no key was pressed.

    while 1:
        ....
        if HasyUtils.inkey() ==  32:  # space bar
            break

    Use
      HasyUtils.inkey( True) 
    to reset the terminal characteristic explicitly. This has to be
    done in particular, if you use sys.exitfunc = yourExitHandler
    which overrides the inkey() exit handler
    '''
    global _initInkey
    global _initInkeyOldTermAttr
    import atexit as _atexit
    import termios as _termios

    if resetTerminal and _initInkey:
        _initInkey = False
        _termios.tcsetattr( _sys.stdin.fileno(), _termios.TCSADRAIN, _initInkeyOldTermAttr)
        return -1

    #
    # changing the terminal attributes takes quite some time,
    # therefore we cannot change them for every inkey() call
    #
    if not _initInkey:
        _initInkey = True
        _initInkeyOldTermAttr = _termios.tcgetattr( _sys.stdin.fileno())
        new = _termios.tcgetattr( _sys.stdin.fileno())
        new[3] = new[3] & ~_termios.ICANON & ~_termios.ECHO
        #
        # VMIN specifies the minimum number of characters to be read
        #
        new[6] [_termios.VMIN] = 0
        #
        # VTIME specifies how long the driver waits for VMIN characters.
        # the unit of VTIME is 0.1 s. 
        #
        new[6] [_termios.VTIME] = 1
        _termios.tcsetattr( _sys.stdin.fileno(), _termios.TCSADRAIN, new)
        _atexit.register( _inkeyExitHandler)
	    
    key = _sys.stdin.read(1)
    if( len( key) == 0):
        key = -1
    else:
        key = ord( key)

    return key

def createScanName( prefix, scanDir = None):
    '''
      Inputs: 
       - prefix
       - scanDir (optional)
      Output: prefix_00123 (e.g.)
        The default directory (or scanDir) is searched for files
        that match the pattern prefix*. The returned name
        contains a number which is one above the existing. 
    '''
    import re as _re
    import glob as _glob
    oldDir = _os.getcwd()
    if scanDir:
        if not _os.path.isdir( scanDir):
            print( "createScanName: %s is not a directory" % scanDir)
            _os.chdir( oldDir)    
            return None
        _os.chdir( scanDir)
    files = _glob.glob( "%s*" % prefix)
    if scanDir:
        _os.chdir( oldDir)    
    if len(files) == 0:
        return "%s_00001" % prefix
    no = 1
    patt = _re.compile( prefix + "_(\d+)\.*(.*)")
    for file in sorted(files):
        parts = patt.match( file)
        if not parts:
            continue
        if int( parts.group(1)) > no:
            no = int( parts.group(1))
    argout = "%s_%05d" % (prefix, no + 1)

    if scanDir:
        _os.chdir( scanDir)
    if len( _glob.glob( "%s*" % argout)) > 0:
        print( "createScanName: failed to create a scan name for %s" % prefix)
        _os.chdir( oldDir)    
        return None
    if scanDir:
        _os.chdir( oldDir)    
    return argout

def uptime():
    '''
    return system uptime in seconds as float number
    '''
    with open('/proc/uptime', 'r') as file:
        return float(file.readline().split()[0])

def configMacroServer( cmdList):
    ''' receives a list of commands which are executed
        on a MacroServer via the first door
    '''
    try:
        p = _PyTango.DeviceProxy( getDoorNames()[0])

    except:
        print( "configMacroServer.py: failed to create a proxy to %s" % getDoorNames()[0])
        return 255

    for cmd in cmdList:
        print( "TgUtils.configMS: %s" % cmd)
        try:
            p.runMacro(cmd.split())
        except: 
            print( "TgUtils.configMS: failed to execute %s" % cmd)
        #
        # make sure that the execution of a command has 
        # finished before the next command is invoked.
        #
        while p.state() != _PyTango.DevState.ON:
            _time.sleep(0.01)
    return 0

def setEnvCautious( dctIn):
    '''
    input: dictionay containing environment variables, names and values, 
    they are set, if the variable does not exist so far.
    '''
    lst = getMacroServerNames()
    tangoHost = _os.environ[ 'TANGO_HOST'].split(':')[0]
    if not lst:
        print( "%s has no MacroServer" % ( tangoHost))
        return
    for elm in lst:
        ms = _PyTango.DeviceProxy( elm)
        dct = _CodecFactory().getCodec('pickle').decode(ms.Environment)[1]['new']
        for key in list( dctIn.keys()):
            if key not in dct:
                print( "TgUtils.setEnvCoutious: senv %s %s " % (key, dctIn[key]))
                dct[key] = dctIn[key]
            else:
                print( "TgUtils.setEnvCautious: %s exists already: %s, not changed to %s" % (key, dct[key], dctIn[key]))

        newDct = dict(new=dct)
        ms.write_attribute( "Environment", _CodecFactory().getCodec('pickle').encode(('', newDct)))

def setEnvDct( dctIn):
    '''
    input: dictionary containing environment variables, names and values.

    After this function executed, dctIn will be the MacroServer environment. 
    Keys that are in the current environment, but not in dctIn are deleted with usenv.

    an error is thrown if the number of MacroServers is != 1
    an error is thrown if the number of Doors is != 1

    the HasyUtils.getEnvDct() returns a Dct that can be modified
    and used by this function

    '''

    lst = getMacroServerNames()
    ms = _PyTango.DeviceProxy( lst[0])
    tangoHost = _os.environ[ 'TANGO_HOST'].split(':')[0]
    if len(lst) != 1:
        print( "%s, expecting ONE MacroServer" % ( tangoHost))
        return

    lst = getDoorNames()
    if len( lst) != 0:
        print( "%s, expecting ONE Door" % ( tangoHost))
        return
        
    door = _PyTango.DeviceProxy( lst[0])

    #
    # compare the 2 dictionaries
    #   if the a variable is not in the new dct, it is deleted
    #   with usenv from the MacroServer environment
    #
    dctOld = getEnvDct()
    for k in list( dctOld.keys()): 
        if k not in list( dctIn.keys()):
            print( "TgUtils.setEnvDct() removing %s" % k)
            door.runmacro(['usenv', k])
            while door.state() is _PyTango.DevState.RUNNING: 
                _time.sleep( 0.01)

    newDct = dict(new=dctIn)
    ms.write_attribute( "Environment", _CodecFactory().getCodec('pickle').encode(('', newDct)))

    return 

def setEnv( key, value):
    '''
    set an environment variable, returns 0, if move than one MS exist
    '''
    lst = getMacroServerNames()
    tangoHost = _os.environ[ 'TANGO_HOST'].split(':')[0]
    if not lst:
        print( "%s has no MacroServer" % ( tangoHost))
        return
    if len( lst) > 1: 
        print( "%s has more that one MacroServer %s" % ( tangoHost, str(lst)))
        return
        
    for elm in lst:
        ms = _PyTango.DeviceProxy( elm)
        dct = _CodecFactory().getCodec('pickle').decode(ms.Environment)[1]['new']
        dct[key] = value
        newDct = dict(new=dct)
        ms.write_attribute( "Environment", _CodecFactory().getCodec('pickle').encode(('', newDct)))

def unsetEnv( key):
    '''
    unset set an environment variable, returns 0, if move than one MS exist
    '''
    lst = getMacroServerNames()
    tangoHost = _os.environ[ 'TANGO_HOST'].split(':')[0]
    if not lst:
        print( "%s has no MacroServer" % ( tangoHost))
        return
    if len( lst) > 1: 
        print( "%s has more that one MacroServer %s" % ( tangoHost, str(lst)))
        return

    lst = getDoorNames()
    if not lst:
        print( "%s has no Door" % ( tangoHost))
        return
        
    door = _PyTango.DeviceProxy( lst[0])
    if getEnv( key) is None:
        return
    
    door.runmacro(['usenv', key])

def getEnv( key):
    '''
    return the value of a macroserver environment variable
    '''
    lst = getMacroServerNames()
    tangoHost = _os.environ[ 'TANGO_HOST'].split(':')[0]
    if not lst:
        print( "%s has no MacroServer" % ( tangoHost))
        return None
    if len( lst) > 1:
        print( "more than one MacroServer %s" % lst)
        return None

    ms = _PyTango.DeviceProxy( lst[0])
    dct = _CodecFactory().getCodec('pickle').decode(ms.Environment)[1]['new']
    if key not in dct:
        return None
    return dct[ key]

def storeEnv( dirName = None):
    '''
    Store the MacroServer environment in dirName
    Default dirName: ScanDir
    Full file name: ScanDir/ScanFilePrefix_ScanID.env
      ScanFilePrefix is extracted from ScanFile

    returns None, if
      - there is no MacroServer
      - there is more than 1 MacroServer
      - dirName does not exist
      - the full file name exists already

    otherwise returns full file name
    '''
    import pprint

    lst = getMacroServerNames()
    tangoHost = _os.environ[ 'TANGO_HOST'].split(':')[0]
    if not lst:
        print( "%s has no MacroServer" % ( tangoHost))
        return None
    if len( lst) > 1:
        print( "more than one MacroServer %s" % lst)
        return None

        
    ms = _PyTango.DeviceProxy( lst[0])
    dct = _CodecFactory().getCodec('pickle').decode(ms.Environment)[1]['new']

    if dirName is None:
        dirName = dct[ 'ScanDir']

    scanID = dct[ 'ScanID']
    scanFile = dct[ 'ScanFile']
    if type( scanFile) == list:
        prefix = scanFile[0].split('.')[0]
    else:
        prefix = scanFile.split('.')[0]
    pathName = "%s/%s_%05d.env" % (dirName, prefix, int(scanID))
    
    if not _os.path.exists( dirName):
        print( "HasyUtils.storeEnv: %s does not exist" % dirName)
        return None
    
    if _os.path.exists( pathName):
        print( "HasyUtils.storeEnv: %s exists already" % pathName)
        return None

    envFile = open( pathName, 'w')
    pp = pprint.PrettyPrinter( indent = 4, stream=envFile)
    pp.pprint( dct)
    envFile.close()

    if _os.isatty(1):
        print( "HasyUtils.storeEnv: created %s" %pathName)

    return pathName

def getEnvVarAsDct( key):
    '''
    return the value of a macroserver environment variable as a dictionary.

    Use case _GeneraHooks: 

    p99/door/haspp99.01 [17]: lsgh
      Hook place        Hook(s)
    ------------ --------------
       post-scan   gh_post_scan
       pre-scan    gh_pre_scan

    return: {'post-scan': ['gh_post_scan'], 'pre-scan': ['gh_pre_scan']}
    '''
    lst = getMacroServerNames()
    tangoHost = _os.environ[ 'TANGO_HOST'].split(':')[0]
    if not lst:
        print( "%s has no MacroServer" % ( tangoHost))
        return None
    if len( lst) > 1:
        print( "more than one MacroServer %s" % lst)
        return None

    ms = _PyTango.DeviceProxy( lst[0])
    dct = _CodecFactory().getCodec('pickle').decode(ms.Environment)[1]['new']
    if key not in dct:
        return None

    hsh = {}
    for elm in dct[ key]:
        k = elm[1][0]
        v = elm[0]
        if k not in hsh:
            hsh[k] = []
        #
        # avoid double entries
        #
        if not v in hsh[k]:
            hsh[k].append( v)
    
    return hsh

def getEnvDct():
    '''
    return the macroserver environment as a dictionary

    If MsNameIn is supplied, considerable TangoDB I/O is saved
    '''
    global _macroServerProxy

    if _macroServerProxy is None: 
        lst = getMacroServerNames()
        if not lst:
            tangoHost = _os.environ[ 'TANGO_HOST'].split(':')[0]
            print( "TgUtils.getEnvDct:%s has no MacroServer" % ( tangoHost))
            return None
        if len( lst) > 1:
            print( "TgUtils.getEnvDct: more than one MacroServer %s" % lst)
            return None
        _macroServerProxy = _PyTango.DeviceProxy( lst[0])
        
    try: 
        dct = _CodecFactory().getCodec('pickle').decode( _macroServerProxy.Environment)[1]['new']
    except: 
        #
        # SardanaAIO is executed
        #
        dct = None

    return dct
#
#
#
class sockel( object):
    ''' 
    A socket server interface which has been created to handle connects
    from Sardana macros to the SardanaMonitor and the message window.
    The constructor checks for available ports in the range [port, port + 9]
                
    Server:
    ------

    def main(): 
       thread.start_new_thread( socketAcceptor, ())      

    def socketAcceptor():
        # waits for new accepts on the original socket, 
        # receives the newly created socket and 
        # creates a thread for the socketServer
        while True:
            s = TgUtils.sockel( TgUtils.getHostname(), PORT)
            thread.start_new_thread( socketServer, (s, ))      

    def socketServer(s):
        global msgBuf
        while True:
            msg = s.recv().strip()
            if msg is None:
                print( "received None, closing socket")
                s.close()
                break
            msgBuf.append( msg)
            s.send( "done")
    '''
    #
    # one socket for the port, accept() generates new sockets
    #
    sckt = None
    conCounter = 0

    def __init__( self, host, port):
        if sockel.sckt is None:
            try:
                sockel.sckt = _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM)
            except Exception as e:
                print( "socket() failed %s" % repr( e))
                _sys.exit()

            for i in range(10):
                port += i
                try:
                    sockel.sckt.bind((host, port))
                except Exception as e:
                    print( "TgUtils.sockel: bind() failed %s,trying next port" % repr( e))
                    continue
                self.port = port
                print( "bind( %s, %d) ok" % (host, port))
                sockel.sckt.listen(5)
                break
            else:
                print( "bind() failed")
                _sys.exit()
        self.conn, addr = sockel.sckt.accept()
        self.addr = addr
        self.connNo = sockel.conCounter
        sockel.conCounter += 1

    def close( self):
        #
        # close the 'accepted' socket only, not the main socket
        # because it may still be in use by another client
        #
        if not self.conn is None:
            self.conn.close()

    def recv( self):
        argout = None
        try:
            argout = self.conn.recv(1024)
        except:
            argout = None
        return argout

    def send( self, msg):
        if self.conn is None:
            return 0
        argout = 0
        try:
            argout = self.conn.send( msg)
        except: 
            self.conn = None
            argout = 0
        return argout

def walkLevel( some_dir, level=1):
    '''
    An extension of _os.walk() allowing the specification of a search depth
    
    Usage: 

      RootDir = '/home/someUser'
      for rootDir, subDirs, files in TgUtils.walkLevel( RootDir, level=0):
          print( "the directory %s" % rootDir )
          print( "contains these files %s" % str( files))
          print( "and these sub-dirs %s" % str( subDirs))
    '''
    some_dir = some_dir.rstrip(_os.path.sep)
    if not _os.path.isdir(some_dir):
        print( "walkLevel %s not a directory" % some_dir)
            
    num_sep = some_dir.count(_os.path.sep)
    for root, dirs, files in _os.walk(some_dir):
        yield root, dirs, files
        num_sep_this = root.count(_os.path.sep)
        if num_sep + level <= num_sep_this:
            del dirs[:]

#
#
# 
def putDeviceProperty( devName, propName, props, tangoHost = None):
    '''
    devName:  'p17/macroserver/haspp17.01'
    propName: 'MacroPath'
    props:    <str> or seq<str>    
    tangoHost e.g.: "haspp99:10000"
    '''
    
    db = _findDB( tangoHost)
    if not db:
        return None

    try:
        db.put_device_property( devName, { propName : props}) 
    except _PyTango.DevFailed as e:
        _PyTango.Except.print_exception( e)
        print( "pooltools.putDeviceProperty: %s %s" % (propName, props))
        return False
    return True
#
#
# 
def deleteDeviceProperty( devName, propName, tangoHost = None):
    '''
    devName:  'p17/macroserver/haspp17.01'
    propName: 'BadPropName'
    tangoHost: 'haspp99:10000'
    '''
    
    db = _findDB( tangoHost)
    if not db:
        return None

    try:
        db.delete_device_property( devName, [ propName]) 
    except _PyTango.DevFailed as e:
        _PyTango.Except.print_exception( e)
        print( "pooltools.deleteDeviceProperty: %s %s" % (propName, props))
        return False
    return True
#
#
# 
def getDeviceProperty( devName, propName, tangoHost = None):
    '''
    return a list containing property values
      devName:  'p17/macroserver/haspp17.01'
      propName: 'MacroPath'
    tangoHost e.g.: "haspp99:10000"
    '''
    
    db = _findDB( tangoHost)
    if not db:
        return None

    try:
        dct = db.get_device_property( devName, [ propName])
    except _PyTango.DevFailed as e:
        _PyTango.Except.print_exception( e)
        print( "pooltools.getDeviceProperty: %s " % (propName))
        return False
    return list(dct[ propName])

def putServerInfo( name = None, host = None, mode = 1, level = None):
    '''
    add/update server information in the database
    '''
    serverInfo = _PyTango.DbServerInfo()
    serverInfo.name = name
    serverInfo.host = host
    serverInfo.level = level
    serverInfo.mode = mode
    _db.put_server_info( serverInfo)
    return True

def restartServer( serverName, tangoHost = None):
    '''
    stop server, then start server, e.g. MacroServer/haspp17
    tangoHost e.g.: "haspp99:10000"
    '''

    if not stopServer( serverName, tangoHost):
        print( "TgUtils.restartServer: failed to stopServer %s " % serverName)
        return False

    if not startServer( serverName, tangoHost):
        print( "TgUtils.restartServer: failed to startServer %s" % serverName)
        return False

    return True
        
def startServer( serverName, tangoHost = None):
    '''
    startServer( "DGG2/Clone")
    startServer( "DGG2/Clone", "haspp99:10000")
    '''
    starter = getStarterDevice( serverName, tangoHost)
    try:
        starterProxy = _PyTango.DeviceProxy( starter)
        starterProxy.command_inout( "UpdateServersInfo")
    except:
        print( "failed to create proxy to starter, server %s, tangoHost %s" % (serverName, tangoHost))
        _sys.exit( 255)

    starterProxy.DevStart( serverName)
        
    print( "Waiting for %s to start " % serverName)
    waitTime = 25 # changed to 25 15.8.2019
    while waitTime > 0:
        _time.sleep(0.5)
        waitTime -= 0.5
        lst = starterProxy.command_inout("DevGetRunningServers", True)
        if serverName in lst:
            break
        _sys.stdout.write( '.')
        _sys.stdout.flush()
    else:
        print( "TgUtils.startServer: %s did not start" % serverName)
        return False
        
    print( "\n%s started (wait-time left %g)" % (serverName, waitTime))
    return True

def _process_exists(srvName):
    #
    # MacroServer/haspp09 -> MacroServer, haspp09
    #
    tsName, instance = srvName.split("/")
    #
    # temp: "MacroServer haspp09"
    #
    temp = "%s %s" % (tsName, instance)
    inp = _os.popen('ps ax | grep %s' % tsName).read()
    lst = inp.split('\n')
    for line in lst:
        if line.find( temp) > 0:
            #print( "_process_exists: True")
            return True
    #print( "_process_exists: False")
    return False

def _serverReallyStopped( proxy, serverName):
    '''
    use 'ps -ax' to see, if a server is really stopped
    '''
    #
    # if the server runs on another host, assume it is stopped
    #
    if getHostnameLong() != proxy.info().server_host:
        print( "TgUtils._serverReallyStopped: local host %s, starterHost %s " % \
            (getHostnameLong(), proxy.info().server_host))
        return True

    if _process_exists( serverName):
        print( "TgUtils.stopServer: hardkill(1) %s" % serverName)
        proxy.command_inout("HardKillServer", serverName)            
        count = 0
        while count < 10:
            if _process_exists( serverName):
                _time.sleep(0.2)
                print( "TgUtils._serverReallyStopped: %s still in 'ps -ax'" % serverName)
                count += 1
            else:
                #print( "TgUtils._serverReallyStopped: %s not in 'ps -ax'" % serverName)
                return True
    else:
        #print( "TgUtils._serverReallyStopped: %s not in 'ps -ax'" % serverName)
        return True

def stopServer( serverName, tangoHost = None):
    '''
    stops a server, e.g. 
    stopServer( "DGG2/Clone")
    stopServer( "DGG2/Clone", "haspp99:10000")
    '''
    starter = getStarterDevice( serverName, tangoHost)
    try:
        starterProxy = _PyTango.DeviceProxy( starter)
    except:
        print( "TgUtils.stopServer: failed to create proxy to starter, server %s, tangoHost %s" %( serverName, tangoHost))
        return None

    lst = starterProxy.command_inout("DevGetStopServers", True)
    if serverName in lst: 
        if _serverReallyStopped( starterProxy, serverName):
            return True

    starterProxy.DevStop( serverName)
        
    print( "Waiting for %s to stop " % serverName)
    waitTime = 10
    while waitTime > 0:
        _time.sleep(0.5)
        waitTime -= 0.5
        starterProxy.command_inout("UpdateServersInfo")
        lst = starterProxy.command_inout("DevGetStopServers", True)
        if serverName in lst:
            if _serverReallyStopped( starterProxy, serverName):
                print( "\nTgUtils.stopServer: %s stopped" % serverName)
                _time.sleep(2.)
                return True
        _sys.stdout.write( '.')
        _sys.stdout.flush()

    print( "TgUtils.stopServer: %s did not stop" % serverName)
    return False

def getStarterDevice( serverName, tangoHost = None):
    '''
    return the starter device for a server, fully qualified
    tangoHost e.g.: "haspp99:10000"
    '''
    
    db = _findDB( tangoHost)
    if not db:
        return None

    try:
        srvInfo = db.get_server_info( serverName)
    except:
        print( "TgUtils.getStarterDevice: failed to get_server_info for %s" % serverName)
        return None

    if len( srvInfo.host.strip()) == 0:
        #
        # there is no host entry, if the server is not controlled by the starter
        #
        return None

    lst = srvInfo.host.split( '.')
    argout = "//%s:10000/tango/admin/%s" % (db.get_db_host(), lst[0])
    return argout


def assertServerRunning( serverName, dbHost = None):
    '''

    use case: 
      to ensure that long measurements consisting of series of individualScans
      are not interrupted a Tango server crashes. 

    what the function does:
      - get a device belonging to serverName
      - create a device proxy and evaluate the state
        + if OK, return True 
        + otherwise
          o wait until the server is no longer in the list of running servers
          o wait until the server appears in the list of stopped servers
          o start the server

    implementation principle

      while True:
         try:
              individualScan()
         except:
              HasyUtils.assertServerRunning( "ServerInvolved/Instance", "haspp99:10000")

    Another example can be found in the Spock manual, section Helpers.
    '''

    devList = getDeviceNamesByServer( serverName, dbHost)
    if len( devList) == 0:
        print( "TgUtils.assertServerRunning: no devices for %s" % serverName)
        return None

    devName = devList[0]
    if not dbHost is None:
        lst = dbHost.split(':')
        if len(lst) == 2:
            devName = "%s/%s" % (dbHost, devName)
        elif len(lst) == 1:
            devName = "%s:10000/%s" % (dbHost, devName)
        else:
            print( "TgUtils.assertServerRunning: something is wrong with dbHost %s" % dbHost)
            return None
    try: 
        p = _PyTango.DeviceProxy( devName)
        sts = p.state()
        return True
    except: 
        pass

    startTime = _time.time()
    while serverIsRunning( serverName, dbHost):
        _time.sleep(0.5)
        if (_time.time() - startTime) > 10.:
            print( "TgUtils.assertServerRunning: %s remains running" % serverName)
            return False

    startTime = _time.time()
    while not serverIsStopped( serverName, dbHost):
        _time.sleep(0.5)
        if (_time.time() - startTime) > 10.:
            print( "TgUtils.assertServerRunning: %s remains running" % serverName)
            return False

    count= 0
    while True:
        try:
            startServer( serverName, dbHost)
            break
        except _PyTango.DevFailed:
            count += 1
            if count == 5:
                return False
            #extype, value = _sys.exc_info()[:2]
            #for err in value:
            #    print( " reason %s" % err.reason)
            #    print( " desc %s " % err.desc)
            #    print( " origin %s " % err.origin)
            #    print( " severity %s " % err.severity)
            #    print( "")
            _time.sleep(0.5)
    return True

def getAttribute( deviceName, attrName):
    '''
    return the attribute of a device
    '''
    try:
        p = _PyTango.DeviceProxy( deviceName)
    except Exception as e:
        print( e)
        print( "TgUtils.getAttribute: failed to create a proxy to %s" % deviceName)
        return None

    return p.read_attribute( attrName).value    

def stopMovePool( motorNamePool):
    '''
    executs the Stop command on the Pool motor
    '''
    try:
        m = _PyTango.DeviceProxy( motorNamePool)
    except Exception as e:
        print( e)
        print( "TgUtils.stopMovePool: failed to create a proxy to %s" % motorNamePool)
        return None
    try:
        m.command_inout("Stop")
    except Exception as e:
        #print( e)
        print( "TgUtils.stopMovePool: failed to execute 'Stop' on %s" % motorNamePool)
        return False
    return True

def stopMoveTS( motorName):
    '''
    executs the StopMove command on a non-Pool Tango server
    '''
    try:
        m = _PyTango.DeviceProxy( motorName)
    except Exception as e:
        #print( e)
        print( "TgUtils.stopMoveTS: failed to create a proxy to %s" % motorName)
        return None
    try:
        m.command_query( "StopMove")
        try:
            m.command_inout("StopMove")
        except Exception as e:
            #print( e)
            print( "TgUtils.stopMoveTS: failed to execute 'StopMove' on %s" % motorName)
            return False
    except Exception as e:
        print( "TgUtils.stopMoveTS: %s has no StopMove" % motorName)
        return False
    return True

def stopAllMoves():
    '''
    send StopMacro to Doors that are not ON and stop all motors (Pools and TS)
    '''
    doorList = getDoorNames()    
    for doorName in doorList:
        try:
            door = _PyTango.DeviceProxy( doorName)
        except Exception as e:
            print( "TgUtils.stopAllMoves: Failed to create a proxy to %s" % doorName)
        if door.state() != _PyTango.DevState.ON:        
            door.StopMacro()        
    #
    # sent Stop to the Pool motors ...
    #
    poolList = getPoolNames()
    for pool in poolList: 
        motorList = getPoolMotors( pool)
        for motorName in motorList:
            stopMovePool( motorName)
    #
    # and to the Tango servers
    #
    motorList = getMotorNames()
    for motorName in motorList:
        stopMoveTS( motorName)

    return True
        
def getDateTime():
    '''
    return: '15 Feb 2016 10:56:57'
    '''
    return _time.strftime("%d %b %Y %H:%M:%S", _time.localtime())

def getDoty( dateString = None): 
    '''
    return date-of-the-year as a floating point number
    
    dateString == None
       uses the current time
    dateString != None
       converts a string like: 2016-11-17 11:41:21 to 322.4870486111111
    '''
    import datetime, time, re
    if dateString is None:
       tm = time.localtime()
       dateString = "%4d-%02d-%02d %02d:%02d:%02d" % ( tm.tm_year, tm.tm_mon, tm.tm_mday, 
                                                     tm.tm_hour, tm.tm_min, tm.tm_sec)

    patt = re.compile( r".*(\d{4})-(\d{2})-(\d{2})\s*(\d{2}):(\d{2}):(\d{2})")
    res = patt.match( dateString)
    if res is None:
        print( "TgUtils.getDoty: bad format %s" % dateString)
        return None

    lst = res.groups()
    h, m, s = lst[3], lst[4], lst[5]
    a = datetime.datetime( int( lst[0]), int( lst[1]), int( lst[2]))
    argout = float(a.timetuple().tm_yday) - 1. + (float(h)*3600. + float(m)*60 + float(s))/86400.
    return argout

def printCallStack( depth = None):    
    '''
    print the call stack, default depth is 15
    '''
    if depth is None:
        depth = 15

    for n in range( 0, depth):
        try:
            code = _sys._getframe(n).f_code
            print( "printTraceback: depth: %d function: %s file: %s line: %d" % \
                  (n, code.co_name, code.co_filename, code.co_firstlineno))
        except ValueError:
            print( "printTraceback: stopped at level %d" % n)
            break
    return

def yesno( prompt):
    '''
    Prints the prompt string and tests whether is answer is (y)es, case-insensitive
    '''
    _sys.stdout.write( prompt)
    _sys.stdout.flush()
    answer = _sys.stdin.readline().upper().strip()
    if answer.lower() == 'y' or answer.lower() == 'yes':
        return True
    else:
        return False

def match( name, pattern):
    '''
    return True, if pattern matches name
    - pattern is None matches all names

    Examples: 
    HasyUtils.match( "d1_mot01", "d1_mot01") -> True
    HasyUtils.match( "d1_mot01", "d1")       -> True
    HasyUtils.match( "d1_mot01", "d1_mot1")  -> False
    HasyUtils.match( "d1_mot01", "0")        -> True
    HasyUtils.match( "d1_mot01", "0$")       -> False ($ end-of-string)
    HasyUtils.match( "d1_mot01", "mot")      -> True
    HasyUtils.match( "d1_mot01", "^mot")     -> False (^ begin-of-string)
    '''
    import re as _re
    #
    # if no pattern is specified, return True
    #
    if pattern is None:
        return True

    pattern = pattern.lower()
    name = name.lower()

    matchObj = _re.search( pattern, name)
    if matchObj is None:
        return False

    return True

class TypeNames:
    '''
    This class is a bad hack to fake TypeName in msparameter.py  
    It is used by the macro tester
    ''' 
    def __init__( self):
        for name in ['Acquirable',
                     'Any',
                     'Boolean',
                     'CTExpChannel',
                     'Class',
                     'ComChannel',
                     'Constraint',
                     'Controller',
                     'ControllerClass',
                     'ControllerLibrary',
                     'Device',
                     'Door',
                     'Element',
                     'Env',
                     'ExpChannel',
                     'External',
                     'File',
                     'Filename',
                     'Float',
                     'Function',
                     'IORegister',
                     'Instrument',
                     'Integer',
                     'JSON',
                     'Library',
                     'Macro',
                     'MacroClass',
                     'MacroCode',
                     'MacroFunction',
                     'MacroLibrary',
                     'MacroServer',
                     'MacroServerElement',
                     'MacroServerObject',
                     'MeasurementGroup',
                     'Meta',
                     'Motor',
                     'MotorGroup',
                     'MotorParam',
                     'Moveable',
                     'Object',
                     'OneDExpChannel',
                     'ParameterType',
                     'Pool',
                     'PoolElement',
                     'PoolObject',
                     'PseudoCounter',
                     'PseudoMotor',
                     'String',
                     'TangoDevice',
                     'TwoDExpChannel',
                     'User',
                     'ZeroDExpChannel']:       
            setattr( self, name, name)
        return

def getListFromFile( fileName):
    '''
    reads fileName, ignores comment lines, ignores empty lines
    and returs a list of lines
    use case: list of hosts
    '''
    try:
        fileHandle = open( fileName, 'r')
    except Exception as e:
        print( "HasyUtils.getListFromFile: Failed to open %s" % fileName)
        print( repr(e))
        return None

    lines = []
    for line in fileHandle:
        line = line.strip()
        if len( line) == 0:
            continue
        if line.find( "#") == 0:
            continue
        lines.append( line)
    fileHandle.close()
    return lines

def getTraceBackList(): 
    '''
    returns a list of strings containg traceback information
    '''
    argout = []
    for n in range( 0, 50):
        try:
            code = _sys._getframe(n).f_code
            argout.append( "traceback: depth: %d function: %s file: %s line: %d" % 
                         (n, code.co_name, code.co_filename, code.co_firstlineno))
        except ValueError:
            break
    return argout

class moveLoop( object):
    '''
    - motorX, motorY, can be Tango or Pool device names
    - the inner motor executes sweeps between startX and stopX, in units. 
    - timeSweep, the sweep time of the inner motor. The slew rate is adjusted.
    - the outer motor moves from startY to stopY by delta
    '''
    def __init__( self, motorX, startX, stopX, timeSweep, 
                  motorY, startY, stopY, deltaY):

        if motorX == motorY:
            print( "moveLoop.__init__: both motors are identical %s, %s" % ( motorX, motorY))
            _sys.exit(255)

        self.findProxiesAndTangoHost( motorX, motorY)
        self.assertSameCard()
        #
        # install CtrlC handler after the proxies have been created
        #
        _signal.signal(_signal.SIGINT, self.handleCtrlC)
        #
        # stop moves, just to be sure
        #
        self.stopMoves()

        self.startX = startX
        self.stopX  = stopX
        self.startY = startY
        self.stopY  = stopY
        self.deltaY = deltaY
        if self.stopY < self.startY:
            self.deltaY = -abs( self.deltaY)
        else:
            self.deltaY = abs( self.deltaY)
        
        self.timeSweep = timeSweep

        self.makeSomeChecks()

        self.slewRateX = self.proxyX.SlewRate

        self.stepsXStart = (self.startX - self.proxyX.unitcalibration)*self.proxyX.conversion
        self.stepsXStop = (self.stopX - self.proxyX.unitcalibration)*self.proxyX.conversion

        stepsXDelta = self.stepsXStop - self.stepsXStart
        timeMove = abs(float(stepsXDelta)/float(self.proxyX.SlewRate))
        if self.timeSweep < timeMove:
            print( "Requested sweep time too short %g, less than the move time %g" % ( self.timeSweep, timeMove))
            print( "  Possible action: increase the sweep time or increase the slew rate")
            _sys.exit( 255)

        self.slewRateXSweep = float( self.slewRateX)*timeMove/self.timeSweep
        
        print( "TgUtils.moveLoop: timeMove %g, self.timeSweep %g, slewRate %g, slewRateSweeep %d" % \
            (timeMove, self.timeSweep, self.slewRateX, self.slewRateXSweep))

        if self.slewRateXSweep < self.proxyX.BaseRate:
            print( "Requested slew rate %d is less than base rate %d" % \
                (self.slewRateXSweep, self.proxyX.BaseRate))
            _sys.exit()

        self.stepsYDelta = self.deltaY*self.proxyY.conversion

        self.nLoop = abs(int((self.stopY - self.startY)/self.deltaY))
        self.commasX = ','*self.channelX
        self.commasY = ','*self.channelY

        self.paused = False

    def makeSomeChecks( self):
        '''
        make sure the input is OK
        '''
        if self.startX is None: 
            raise Exception( "TgUtils.moveLoop:",  "startX is None")
        if self.stopX is None: 
            raise Exception( "TgUtils.moveLoop:", "stopX is None")

        if self.startY is None: 
            raise Exception( "TgUtils.moveLoop:", "startY is None")
        if self.stopY is None: 
            raise Exception( "TgUtils.moveLoop:", "stopY is None")

        if self.timeSweep <= 0.: 
            raise Exception( "TgUtils.moveLoop:", "timeSweep <= 0 (%g)" % self.timeSweep)

        try:
            if self.proxyX.UnitLimitMin > self.startX or  \
               self.proxyX.UnitLimitMax < self.startX:
                print( "checkLimits: %s startX %g outside limits [%g, %g]" % \
                    (self.motorX, self.startX, 
                     self.proxyX.UnitLimitMin, self.proxyX.UnitLimitMax))
                _sys.exit( 255)
            if self.proxyX.UnitLimitMin > self.stopX or  \
               self.proxyX.UnitLimitMax < self.stopX:
                print( "checkLimits: %s stopX %g outside limits [%g, %g]" % \
                    (self.motorX, self.stopX, 
                     self.proxyX.UnitLimitMin, self.proxyX.UnitLimitMax))
                _sys.exit( 255)

            if self.proxyY.UnitLimitMin > self.startY or \
               self.proxyY.UnitLimitMax < self.startY:
                print( "checkLimits: %s startY %g outside limits [%g, %g]" % \
                    (self.motorY, self.startY, 
                     self.proxyY.UnitLimitMin, self.proxyY.UnitLimitMax))
                _sys.exit( 255)
            if self.proxyY.UnitLimitMin > self.stopY or  \
               self.proxyY.UnitLimitMax < self.stopY:
                print( "checkLimits: %s stopY %g outside limits [%g, %g]" % \
                    (self.motorY, self.stopY, self.proxyY.UnitLimitMin, self.proxyY.UnitLimitMax))
                _sys.exit( 255)
        except Exception as e:
            print( "checkLimits: exception")
            print( (repr(e)))

    def findProxiesAndTangoHost( self, motorX, motorY):
        """
        if pool device names are supplied, find the Tango devices and replace the proxies.
        Set 
          - self.motorX, e.g. p09/motor/d1.66
          - self.tangoHostX, e.g. haso107d1:10000
        """
        self.motorX = motorX
        self.motorY = motorY
        try:
            p = _PyTango.DeviceProxy( self.motorX)
            if hasattr( p, "Velocity"):
                dName = p.TangoDevice
                self.proxyX = _PyTango.DeviceProxy( dName)
            else:
                dName = self.motorX
                self.proxyX = p

            ( mName, hName) = self.splitDeviceNameAndTangoHost( dName)
            self.motorX = mName
            self.tangoHostX = hName

            p = _PyTango.DeviceProxy( self.motorY)
            if hasattr( p, "Velocity"):
                dName = p.TangoDevice
                self.proxyY = _PyTango.DeviceProxy( dName)
            else:
                dName = self.motorY
                self.proxyY = p

            ( mName, hName) = self.splitDeviceNameAndTangoHost( dName)
            self.motorY = mName
            self.tangoHostY = hName

            self.channelX = int( getDeviceProperty( self.motorX, 
                                                                  "Channel", 
                                                                  tangoHost = self.tangoHostX)[0])
            self.channelY = int( getDeviceProperty( self.motorY, 
                                                                  "Channel", 
                                                                  tangoHost = self.tangoHostY)[0])
        except Exception as e:
            print( "Failed to create proxies to the Tango devices")
            print( repr(e))
            _sys.exit( 255)

    def splitDeviceNameAndTangoHost( self, dName):
        """
        haso107d1:10000/p09/motor/d1.66 -> 
          - p09/motor/d1.66
          - haso107d1:10000
        """
        mName = None
        hName = None
        temp = dName.find( "10000")
        if temp > 0:
            # p09/motor/d1.66
            mName = dName[(temp + 6):]
            # haso107d1:10000
            hName = dName[:(temp + 5)]
        else:
            mName = dName
        return ( mName, hName)

    def handleCtrlC( self, par1, par2):
        print( "handleCtrlC")
        self.stopMoves()
        _sys.exit( 255)
 
    def stopMoves( self): 
        self.proxyX.stopMove()
        self.proxyY.stopMove()
        while self.proxyX.state() == _PyTango.DevState.MOVING or \
              self.proxyY.state() == _PyTango.DevState.MOVING:
            print( "stopMoves: waiting for motors to stop")
            _time.sleep( 0.1)
        #
        # stop all
        #
        self.proxyX.command_inout( "WriteRead", "SA;")

    def __del__( self):
        '''
        destructor restores the slew rate
        '''
        self.stopMoves()
        self.proxyX.SlewRate = self.slewRateX

    def assertSameCard( self):
        '''
        make sure both motors are on the same VME card
        '''
        try:
            baseX = int( getDeviceProperty( self.motorX, "Base", tangoHost = self.tangoHostX)[0])
            baseY = int( getDeviceProperty( self.motorY, "Base", tangoHost = self.tangoHostY)[0])
        except Exception as e:
            print( "assertSameCard: exception")
            print( repr(e))
            _sys.exit( 255)

        if baseX != baseY:
            print( "assertSameCard: %s and %s are not on the same card" % (self.motorX, self.motorY))
            _sys.exit( 255)
        
    def toStart( self):
        '''
        start to move both motors to the start position
        '''
        print( "")
        print( "toStart: move %s to %g, %s to %g" % (self.motorX, self.startX,
                                                     self.motorY, self.startY))
        try:
            self.proxyX.position = self.startX
            self.proxyY.position = self.startY
        except Exception as e:
            print( "toStart: failed with %s" % repr( e))
            _sys.exit( 255)
        return True

    def run( self):
        '''
        execute the mesh scan using the loop feature of the VME card
        '''
        #
        # AA: all axes
        # LS: loop
        # VL: set slew rate
        # MA: move absolute
        # GO: go
        # MR: move relative
        # LE: loop end
        # ID: set DONE
        # 
        #cmd = "AA;LS%d;VL%d;MA%s%d;GO;VL%d;MA%s%d;GO;MR%s%d;GO;LE;MA%s%d;GO;ID;VL%d" % \
        #      (self.nLoop, 
        #       self.slewRateX, 
        #       commasX, self.stepsXStart, 
        #       self.slewRateXSweep, 
        #       commasX, self.stepsXStop, 
        #       commasY, self.stepsYDelta, 
        #       commasX, self.stepsXStart,
        #       self.slewRateX)

        #
        # s-shape move
        # 
        # the loop body:
        #  - X: move to stop 
        #  - Y: rel-move
        #  - X: move to start
        #  - Y: rel-move
        #
        cmd = "AA;VL%s%d;LS%d;MA%s%d;GO;MR%s%d;GO;MA%s%d;GO;MR%s%d;GO;LE;MA%s%d;GO;ID;VL%s%d" % \
              (
                self.commasX, self.slewRateXSweep, 
                int( self.nLoop/2. + 1), 
                self.commasX, self.stepsXStop, 
                self.commasY, self.stepsYDelta, 
                self.commasX, self.stepsXStart, 
                self.commasY, self.stepsYDelta, 
                self.commasX, self.stepsXStart,
                self.commasX, self.slewRateX)

        print( "TgUtils.moveLoop.run: %s" % cmd)
        self.proxyX.command_inout( "MoveLoop", cmd)

    def pause( self): 
        '''
        pause a moveLoop, e.g. because of beam loss
        '''
        self.stopMoves()
        self.posXPaused = self.proxyX.position
        self.posYPaused = self.proxyY.position
        self.stepsXPaused = self.proxyX.StepPositionController
        print( "TgUtils: paused at %g %g " % (self.posXPaused, self.posYPaused))
        self.paused = True
        
    def resume( self):
        if not self.paused:
            raise Exception( "TgUtils.moveLoop.resume", "not in paused state")
        nLoopDone = int( (self.posYPaused - self.startY)/ self.deltaY + 0.5)
        print( "TgUtils: resume at x %g, y %g, nLoopDone %d " % (self.posXPaused, self.posYPaused, nLoopDone))

        nLoopResume = self.nLoop - nLoopDone
        #
        # resume to go right
        #
        if nLoopDone % 2 == 0:
            cmd = "AA;LS%d;VL%d;MA%s%d;GO;MR%s%d;GO;MA%s%d;GO;MR%s%d;GO;LE;MA%s%d;GO;ID;VL%d" % \
                  (int( nLoopResume/2. + 1), 
                   self.slewRateXSweep, 
                   self.commasX, self.stepsXStop, 
                   self.commasY, self.stepsYDelta, 
                   self.commasX, self.stepsXStart, 
                   self.commasY, self.stepsYDelta, 
                   self.commasX, self.stepsXStart,
                   self.slewRateX)
        #
        # resume to go left
        #
        else:
            cmd = "AA;LS%d;VL%d;MA%s%d;GO;MR%s%d;GO;MA%s%d;GO;MR%s%d;GO;LE;MA%s%d;GO;ID;VL%d" % \
                  (int( nLoopResume/2. + 1), 
                   self.slewRateXSweep, 
                   self.commasX, self.stepsXStart, 
                   self.commasY, self.stepsYDelta, 
                   self.commasX, self.stepsXStop, 
                   self.commasY, self.stepsYDelta, 
                   self.commasX, self.stepsXStart,
                   self.slewRateX)

        print( "TgUtils.moveLoop.resume: %s" % cmd)
        self.proxyX.command_inout( "MoveLoop", cmd)
        
    def runNormal( self):
        '''
        execute the mesh scan using conventional move commands
        '''
        for i in range( int(self.nLoop/2.)):
            #
            # move forth
            #
            self.proxyX.SlewRate = self.slewRateXSweep
            self.proxyX.Position = self.stopX
            while self.proxyX.state() == _PyTango.DevState.MOVING or \
                  self.proxyY.state() == _PyTango.DevState.MOVING:
                print( "(%d) normal, forth: posX %g, posY %g" % \
                    ( i, self.proxyX.Position, self.proxyY.Position))
                _time.sleep(0.5)
            #
            # rel-move outer
            #
            self.proxyY.Position = self.proxyY.Position + self.deltaY
            while self.proxyY.state() == _PyTango.DevState.MOVING:
                print( "(%d) normal, re-move:  posX %g, posY %g" % \
                    ( i, self.proxyX.Position, self.proxyY.Position))
                _time.sleep(0.5)
            #
            # move back inner and 
            #
            self.proxyX.SlewRate = self.slewRateX
            self.proxyX.Position = self.startX
            while self.proxyX.state() == _PyTango.DevState.MOVING:
                print( "(%d) normal, back:  posX %g, posY %g" % \
                    ( i, self.proxyX.Position, self.proxyY.Position))
                _time.sleep(0.5)
            #
            # rel-move outer
            #
            self.proxyY.Position = self.proxyY.Position + self.deltaY
            while self.proxyY.state() == _PyTango.DevState.MOVING:
                print( "(%d) normal, re-move:  posX %g, posY %g" % \
                    ( i, self.proxyX.Position, self.proxyY.Position))
                _time.sleep(0.5)

    def state( self):
        if self.proxyX.state() == _PyTango.DevState.MOVING or \
           self.proxyY.state() == _PyTango.DevState.MOVING:
            return _PyTango.DevState.MOVING
        else:
            return _PyTango.DevState.ON

try:
    _db = _PyTango.Database()
    _dbProxy = _PyTango.DeviceProxy( "sys/database/2")
except: 
    print( "TgUtils: failed to connect to local DB (informational)")

def petraBeamCurrent():
    '''
    returns the BeamCurrent attribute of the petra/global/keyword device
    '''
    global _petraGlobalsKeyword
    if _petraGlobalsKeyword is None:
        try:
            _petraGlobalsKeyword = _PyTango.DeviceProxy( "petra/globals/keyword")
        except Exception as e:
            print( "TgUtils.petraCurrent: failed to create proxy to petra/globals/keyword")
            print( repr(e))
            return None
    return _petraGlobalsKeyword.BeamCurrent

def petraMachineState():
    '''
    returns the MachineState attribute of the petra/global/keyword device
    '''
    global _petraGlobalsKeyword
    if _petraGlobalsKeyword is None:
        try:
            _petraGlobalsKeyword = _PyTango.DeviceProxy( "petra/globals/keyword")
        except Exception as e:
            print( "TgUtils.petraCurrent: failed to create proxy to petra/globals/keyword")
            print( repr(e))
            return None
    return _petraGlobalsKeyword.MachineState

def petraMachineStateText():
    '''
    returns the MachineStateText attribute of the petra/global/keyword device
    '''
    global _petraGlobalsKeyword
    if _petraGlobalsKeyword is None:
        try:
            _petraGlobalsKeyword = _PyTango.DeviceProxy( "petra/globals/keyword")
        except Exception as e:
            print( "TgUtils.petraCurrent: failed to create proxy to petra/globals/keyword")
            print( repr(e))
            return None
    return _petraGlobalsKeyword.MachineStateText

def petraMachineStateExt():
    '''
    returns the MachineState.ext attribute of the petra/global/keyword device
    '''
    global _petraGlobalsKeyword
    if _petraGlobalsKeyword is None:
        try:
            _petraGlobalsKeyword = _PyTango.DeviceProxy( "petra/globals/keyword")
        except Exception as e:
            print( "TgUtils.petraCurrent: failed to create proxy to petra/globals/keyword")
            print( repr(e))
            return None
    return _petraGlobalsKeyword.read_attribute( "MachineState.ext").value

def petraMachineStateTextExt():
    '''
    returns the MachineStateText.ext attribute of the petra/global/keyword device
    '''
    global _petraGlobalsKeyword
    if _petraGlobalsKeyword is None:
        try:
            _petraGlobalsKeyword = _PyTango.DeviceProxy( "petra/globals/keyword")
        except Exception as e:
            print( "TgUtils.petraCurrent: failed to create proxy to petra/globals/keyword")
            print( repr(e))
            return None
    return _petraGlobalsKeyword.read_attribute( "MachineStateText.ext").value

def petra(): 
    '''
    returns petraBeamCurrent from petra/globals/keyword
    '''
    return petraBeamCurrent()

def toSardanaMonitor( hsh, node = None):
    """
    sends a dictionary to a SardanaMonitor process, 
    returns a dictionary ...

import HasyUtils
import random
MAX = 10
pos = [float(n)/MAX for n in range( MAX)]
d1 = [random.random() for n in range( MAX)]
d2 = [random.random() for n in range( MAX)]

hsh = { 'putData': 
           {'title': "Important Data", 
            'columns': 
            [ { 'name': "d1_mot01", 'data' : pos},
              { 'name': "d1_c01", 'data' : d1},
              { 'name': "d1_c02", 'data' : d2},
           ]}}
smNode = "haso107d1"
if not HasyUtils.isSardanaMonitorAlive(): 
    return False
hsh = HasyUtils.toSardanaMonitor( hsh, node = smNode)
print hsh
if hsh[ 'result'].upper() == 'DONE':
    print( "success!")
    
print HasyUtils.toSardanaMonitor( {'gra_decode_text': "date()"}, node = smNode)
print HasyUtils.toSardanaMonitor( {'gra_decode_int': "2*3"}, node = smNode)
print HasyUtils.toSardanaMonitor( {'gra_decode_double': "sqrt(2.)"}, node = smNode)
print HasyUtils.toSardanaMonitor( {'gra_command': "cls;wait 1;display 1"}, node = smNode)
hsh = HasyUtils.toSardanaMonitor( { 'getData': True})
print repr( hsh.keys())
print repr( hsh['getData'].keys())
print repr( hsh['getData']['D1_C01']['x'])

    """
    import zmq, json, socket

    if node is None:
        node = socket.gethostbyname( socket.getfqdn())

    context = zmq.Context()
    sckt = context.socket(zmq.REQ)
    #
    # prevent context.term() from hanging, if the message
    # is not consumed by a receiver.
    # 
    sckt.setsockopt(zmq.LINGER, 1)
    try:
        sckt.connect('tcp://%s:7778' % node)
    except Exception as e:
        sckt.close()
        return { 'result': "TgUtils.toSardanaMonitor: failed to connect to %s" % node}

    hshEnc = json.dumps( hsh)
    #
    # sending bytearrays seems to work for Python2 and Python3
    #
    if _sys.version_info.major >= 1: 
        hshEnc = bytearray( hshEnc, encoding="utf-8")
    try:
        res = sckt.send( hshEnc)
    except Exception as e:
        sckt.close()
        return { 'result': "TgUtils.toSardanaMonitor: exception by send() %s" % repr(e)}
    #
    # SardanaMonitor receives the Dct, processes it and then
    # returns the message. This may take some time. To pass
    # 4 arrays, each with 10000 pts takes 2.3s
    #
    if 'isAlive' in hsh:
        lst = zmq.select([sckt], [], [], 0.5)
        if sckt in lst[0]:
            hshEnc = sckt.recv() 
            sckt.close()
            context.term()
            return json.loads( hshEnc)
        else: 
            sckt.close()
            context.term()
            return { 'result': 'notAlive'}
    else:
        lst = zmq.select([sckt], [], [], 3.0)
        if sckt in lst[0]:
            hshEnc = sckt.recv() 
            sckt.close()
            context.term()
            return json.loads( hshEnc)
        else: 
            sckt.close()
            context.term()
            return { 'result': 'TgUtils: no reply from SardanaMonitor'}

def isSardanaMonitorAlive( node = None):
    '''
    returns True, if there is a SardanaMonitor responding to the isAlive prompt
    '''
    hsh = toSardanaMonitor( { 'isAlive': True}, node = node)
    if hsh[ 'result'] == 'notAlive':
        return False
    else:
        return True

def getMgConfiguration( mgName): 
    '''   
    return a dictionary containing the configuration of the MG
    '''
    try: 
        p = _PyTango.DeviceProxy( mgName)
    except Exception as e:
        print( "TgUtils.getMgConfiguration: failed to create a proxy to %s" % mgName)
        return None

    return _json.loads( p.Configuration)

def saveAttrsAsPython( tangoHost = None, alias = None, module = None): 
    '''
    creates the versioned file: /online_dir/MotorLogs/MotorAttr<alias>.py

      tangoHost:  if None, translate TANGO_HOST
      alias:      theta
      module:     oms58, omsmaxv, spk,motor_tango

      returns:    fileName
    '''

    motorAttributes = [ 
        'Acceleration',
        'Conversion', 
        'BaseRate', 
        'StepBacklash',
        'CutOrMap', 
        'SlewRateMax',
        'StepPositionController',
        'StepPositionInternal',
        'UnitCalibration', 
        'FlagProtected', 
        'SettleTime',
        'Position', 
        'SlewRateMin',
        'SlewRate',
        'StepCalibration',
        'UnitLimitMax',
        'UnitLimitMin', 
    ]

    encoderAttributes = [ 
        'ConversionEncoder', 
        'CorrectionGain', 
        'EncoderRatio',
        'HomePosition',
        'PositionEncoder',
        'PositionEncoderRaw',
    ]


    #
    # motors are identified by module types
    #
    if( module.lower() != 'oms58' and
        module.lower() != 'omsmaxv' and
        module.lower() != 'spk' and
        module.lower() != 'motor_tango'):
        print( "TgUtils.saveAttrsAsPython: wrong module %s" % module)
        return False

    if tangoHost is None:
        tangoHost = _os.getenv( 'TANGO_HOST')
        if tangoHost is None:
            print( "TgUtils.saveAttrsAsPython: TANGO_HOST is not defined")
            return False


    if alias is None:
        print( "TgUtils.saveAttrsAsPython: alias not specified" )
        return False

    if module is None:
        print( "TgUtils.saveAttrsAsPython: module not specified" )
        return False


    if not _os.path.isdir( '/online_dir/MotorLogs'):
        try:
            _os.mkdir( '/online_dir/MotorLogs')
        except:
            print( "TgUtils.saveAttrsAsPython: Failed to create /online_dir/MotorLogs")
            return False

    try:
        p = _PyTango.DeviceProxy( alias)
    except:
        print( "TgUtils.saveAttrsAsPython: failed to create proxy to %s/%s" % (tangoHost, alias))
        return False

    if hasattr( p, "TangoDevice"): 
        p = _PyTango.DeviceProxy( p.TangoDevice)

    attrs = motorAttributes[:]
    try:
        if( len( p.get_property('FlagEncoder')['FlagEncoder']) > 0 and
            p.get_property('FlagEncoder')['FlagEncoder'][0] == '1'): 
            attrs.extend( encoderAttributes)
    except:
        print( "TgUtils.saveAttrsAsPython: failed to get_property FlagEncoder %s/%s" % (tangoHost, deviceName))

    #
    # if the device has no position, it is not a motor
    #
    if not hasattr( p, "position"):
        print( "TgUtils.saveAttrsAsPython: %s/%s has no attribute position" % ( tangoHost, deviceName))
        return False

    fileName = "/online_dir/MotorLogs/Attr_%s.py" % alias
    if _os.path.exists( '/usr/local/bin/vrsn'):
        _os.system( "/usr/local/bin/vrsn -s -nolog %s" % fileName)
        
    try:
        fileHandle = open( "%s" % fileName, "w")
    except Exception as e:
        print( "TgUtils.saveAttrsAsPython: failed to open %s" % fileName)
        sys.stderr.write( "%s\n" % str( e))            
        return 

    fileHandle.write( "#\n")

    tmStart = _time.localtime()
    fileHandle.write( "#\n# Created at %02d.%02d.%d %02d:%02dh\n#\n" % 
                      (tmStart[2], tmStart[1], tmStart[0], tmStart[3], tmStart[4]))
    fileHandle.write( "# Selected attributes of %s, %s ( %s) \n" % (alias, p.dev_name(), module))
    fileHandle.write( "#\n")
    fileHandle.write( "# This is a versioned file \n")
    fileHandle.write( "#\n")
    fileHandle.write( "# To restore the attributes:\n")
    fileHandle.write( "#  $ python %s\n" % fileName)
    fileHandle.write( "#\n")
    fileHandle.write( "import PyTango\n")
    fileHandle.write( "print \" restoring %s/%s (%s) \"\n" % ( tangoHost, p.dev_name(), alias))
    fileHandle.write( "proxy = PyTango.DeviceProxy( \"%s/%s\")\n" % (tangoHost, p.dev_name()))
    #
    # we log encoder attributes only, if the FlagEncoder property is '1'
    #
    attrs = motorAttributes[:]
    try:
        if( len( p.get_property('FlagEncoder')['FlagEncoder']) > 0 and
            p.get_property('FlagEncoder')['FlagEncoder'][0] == '1'): 
            attrs.extend( encoderAttributes)
    except:
        print( "TgUtils.saveAttrsAsPython: trouble getting FlagEncoder for %s" % p.dev_name())

    for attr in attrs:
        if hasattr( p, attr.lower()):
            try:
                attrValue = p.read_attribute( attr.lower()).value
                attrInfo = p.get_attribute_config( attr.lower())
            except:
                continue
            if attr.lower() == 'position':
                fileHandle.write( "# proxy.write_attribute( \"%s\", %s) [Attr. config: %s, %s]\n" % \
                                      (attr.lower(), attrValue, str(attrInfo.min_value), str( attrInfo.max_value)))
                continue
            if attrInfo.writable == _PyTango._PyTango.AttrWriteType.READ_WRITE:
                # resultsPython.append( "print( \"  %s: %s\"\n" % (attr.lower(), attrValue)))
                fileHandle.write( "proxy.write_attribute( \"%s\", %s)\n" % (attr.lower(), attrValue))
            else:
                fileHandle.write( "# read-only attribute %s was %s\n" % (attr.lower(), attrValue))

    try:
        attrValue = p.read_attribute( "UnitCalibrationUser").value
        fileHandle.write( "proxy.write_attribute( \"UnitCalibrationUser\", 0.0)\n")
    except:
        pass

    fileHandle.close()

    return fileName


def getLivingLocalPoolNames():
    '''
    return a list poolNames that respond to state()
    '''
    lst = getLocalPoolNames()
    poolNames = []
    for poolName in lst:
        try:
            p = _PyTango.DeviceProxy( poolName)
            sts = p.state()
        except:
            print( "getLivingLocalPoolNames: no response from %s, ignore" % poolName)
            continue
        poolNames.append( poolName)
    return poolNames


def configureControllers( logLevel = None): 
    '''
    logLevel is not None
      set the controller LogLevel attribute to logLevel, Zibi: 30, def. 10
    logLevel is None
      print the controller LogLevel attribute

    Background: debug haspp08 'Measurement group ended acquisition with Fault state'
    '''
    poolNames = getLivingLocalPoolNames()
    for poolName in poolNames: 
        try: 
            pool = _PyTango.DeviceProxy( poolName)
        except:
            print( "TgUtils.configureControllers: failed to get proxy to %s" % poolName)
            return 0
        ctrlList = pool.ControllerList
        for ctrl in ctrlList: 
            hsh = _json.loads( ctrl)
            try: 
                p = _PyTango.DeviceProxy( hsh[ 'full_name'])
            except Exception as e: 
                print( "TgUtils.configureController: %s" % repr( e))
                continue
            if logLevel is not None: 
                p.LogLevel = logLevel
            print( "TgUtils.confCtrl: %s LogLevel %d" % ( p.name(), p.LogLevel))

    return 

def toPyspMonitor( hsh, node = None, testAlive = False):
    '''
    Send a dictionary to the pyspMonitor process via ZMQ. 
    pyspMonitor processes the dictionary by calling PySpectra.toPyspLocal()

    testAlive == True: 
        it is checked whether a pyspMonitor process responds to 
        the { 'isAlive': True} dictionary. 
          if not, pyspMonitor is launched

    Example: 
      if not HasyUtils.isPyspMonitorAlive():
          return False
      ret = HasyUtils.toPyspMonitor( {'command': ['delete', 'cls', 'create s1', 'display']})
      if ret[ 'result'] != 'done': 
          print( "error" % ret[ 'result'])

    ---
    '''
    import zmq, json, socket

    #
    # testAlive == True reduces the rate from 625 Hz to 360 Hz
    #
    if testAlive: 
        (status, wasLaunched) = assertPyspMonitorRunning()
        if not status: 
            raise ValueError( "TgUtils.toPyspMonitor: trouble with pyspMonitor")

    if node is None:
        node = socket.gethostbyname( socket.getfqdn())

    context = zmq.Context()
    sckt = context.socket(zmq.REQ)
    #
    # prevent context.term() from hanging, if the message
    # is not consumed by a receiver.
    #
    sckt.setsockopt(zmq.LINGER, 1)
    try:
        sckt.connect('tcp://%s:7779' % node)
    except Exception as e:
        sckt.close()
        print( "TgUtils.toPyspMonitor: connected failed %s" % repr( e))
        return { 'result': "TgUtils.toPyspMonitor: failed to connect to %s" % node}

    # print( "TgUtils.toPyspMonitor: connected to tcp://%s:7779" % node)
    
    replaceNumpyArrays( hsh)

    #print( "TgUtils.toPyspMonitor: sending %s" % hsh)

    hshEnc = json.dumps( hsh)
    try:
        res = sckt.send( bytearray( hshEnc, encoding="utf-8"))
    except Exception as e:
        sckt.close()
        return { 'result': "TgUtils.toPyspMonitor: exception by send() %s" % repr(e)}
    #
    # PyspMonitor receives the Dct, processes it and then
    # returns the message. This may take some time. To pass
    # 4 arrays, each with 10000 pts takes 2.3s
    #
    if 'isAlive' in hsh:
        lst = zmq.select([sckt], [], [], 0.5)
        if sckt in lst[0]:
            hshEnc = sckt.recv() 
            sckt.close()
            context.term()
            argout = json.loads( hshEnc)
        else: 
            sckt.close()
            context.term()
            argout = { 'result': 'notAlive'}
    else:
        lst = zmq.select([sckt], [], [], 3.0)
        if sckt in lst[0]:
            hshEnc = sckt.recv() 
            sckt.close()
            context.term()
            argout = json.loads( hshEnc) 

        else: 
            sckt.close()
            context.term()
            argout = { 'result': 'TgUtils.toPyspMonitor: communication time-out'}

    #print( "TgUtils.toPyspMonitor: received %s" % argout)
    return argout

def isPyspMonitorAlive( node = None):
    '''
    returns True, if there is a pyspMonitor responding to the isAlive prompt
    '''
    hsh = toPyspMonitor( { 'isAlive': True}, node = node, testAlive = False)
    if hsh[ 'result'] == 'notAlive':
        return False
    else:
        return True


def replaceNumpyArrays( hsh): 
    """
    find numpy arrays in the hsh and replace the by lists
    """
    for k in list( hsh.keys()): 
        if type( hsh[ k]) is dict:
            replaceNumpyArrays( hsh[ k])
            continue
        if type( hsh[ k]) is list:
            for elm in hsh[ k]: 
                if type( elm) is dict:
                    replaceNumpyArrays( elm)
        if type( hsh[ k]) is np.ndarray: 
            #
            # Images, that have been created by tolist() need width and height
            # if width and height are not supplied, take them from .shape
            #
            if len( hsh[ k].shape) == 2:
                if not 'width' in hsh: 
                    hsh[ 'width'] = hsh[ k].shape[0]
                if not 'height' in hsh: 
                    hsh[ 'height'] = hsh[ k].shape[1]
            hsh[ k] = hsh[ k].tolist()

    return


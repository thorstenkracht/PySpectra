#!/usr/bin/env python 
'''
nxsReader( fileName) returns an object containing the nexus file
'''

__all__ = ['nxsReader', 'argSupplied', 'NxsGroup', 'NxsField', 'NxsAttr', 'NxsLink']

import sys as _sys
import os as _os
import argparse as _argparse
import string as _string
import numpy as _np

try:
    import pni.io.nx.h5 as _nexus
except:
    pass

flagTTY = _os.isatty( 1)


def argSupplied( arg):
    '''
    for optional arguments that may have a parameter. 
    return True, if the optional arguments was supplied, with or 
    without a parameter, e.g. '--dev' or '--dev exp.01' --> true
    '''
    if arg is None:
        return True
    #
    # ndim = 2
    #
    elif not type( arg) is str:
        return True
    elif arg.find( 'Missing') == 0:
        return False
    else:
        return True

def match( pathName, pattern):
    '''
    return True, if pattern matches pathName
    - pattern == None matches all pathNames
    - re.search( pattern, pathName)
    '''
    import re
    #
    # if no pattern is specified, return True
    #
    if pattern is None:
        return True

    pattern = pattern.lower()
    pathName = pathName.lower()

    matchObj = re.search( pattern, pathName)
    if matchObj is None:
        return False

    return True

def _prepareValue( line):
    ''' limit the string to about 40 characters '''
    line = str(line).replace( "\n", "<nl>")
    if len(line) > 60: line = line[:30] + "... " + line[(len(line) - 30):]
    return line

class _NxsItem():
    '''
    the base class for groups, fields, links and attributes
    '''
    def __init__( self, parent, name, path):
        self.parent     = parent
        self.name       = name
        self.path       = path
        if self.parent is None:
            self.level = 1
        else:
            self.level      = parent.level + 1
            self.nxsObj     = self.parent.nxsObj
            self.nxsObj.pathDct[ path] = self
        #
        # className: nxgroup, nxfield, nxattribute
        #
        #self.className = item.__class__.__name__
        #
        # nxClass is NXentry, NXmonitor, NXdata, NXinstrument, 
        #   NXcollection, NXinsertion_device, NXsource, NXsample 
        #
        #if self.className == 'nxgroup':
        #    self.nxClass = _nexus.get_class( item)

    def _someBlanks( self):
        return " ".join(" " for i in range(self.level))

class NxsGroup( _NxsItem):
    '''
    groups can have: groups, field, links and attributes
    '''
    def __init__( self, parent, name, path, nxsClass):
        _NxsItem.__init__( self, parent, name, path)
        self.attributes = []
        self.fields = []
        self.groups = []
        self.links = []
        self.nxsClass = nxsClass

        return

    def display( self):
        if self.parent is None:
            self.nxsObj.outputBuffer.append( "%s %d Group: name: %s, parent: None" % \
                                             (self._someBlanks(), self.level, self.name))
            self.nxsObj.outputBuffer.append( "%s   path: %s" % \
                                             (self._someBlanks(), self.path))
        else:
            self.nxsObj.outputBuffer.append("%s %d Group: name: %s, parent: %s" % \
                                            (self._someBlanks(), self.level, self.name, self.parent.name))
            self.nxsObj.outputBuffer.append( "%s    path: %s" % \
                                             (self._someBlanks(), self.path))

        for attr in self.attributes: attr.display()
        for field in self.fields:    field.display()
        for link in self.links:      link.display()

        for group in self.groups:    group.display()

        return

    def create( self, parent): 

        for attr in self.attributes: attr.create( parent)
        for field in self.fields:    field.create( parent)
        for link in self.links:      link.create( parent)

        #
        # since grp.nxsClass is supplied, an attribute NX_class will be created
        #
        for grp in self.groups:
            group = parent.create_group( grp.name, grp.nxsClass)
            grp.create( group)

    def search( self, patternDct):

        if argSupplied( patternDct[ 'group']):
            if match( self.path, patternDct['group']):
                off = " " * self.level
                self.nxsObj.outputBuffer.append( "%s %d Group: %s, %s" % (off, self.level, self.name, self.path))

        for attr in self.attributes:
            attr.search( patternDct)
        for field in self.fields:
            field.search( patternDct)
        for link in self.links:
            link.search( patternDct)

        for grp in self.groups:
            grp.search( patternDct)
        return 

class NxsField( _NxsItem):
    '''
    fields can have attributes
    '''
    def __init__( self, parent, name, path, dtype, shape, value):
        _NxsItem.__init__( self, parent, name, path)
        self.dtype  = dtype # <type 'str'>
        #
        # shape is a tuple, use len() to get the dimension of the field
        #
        self.shape  = shape
        self.value  = value
        self.attributes = []

        return 


    def ausgabe( self, patternDct): 

        if patternDct and 'text' in patternDct and patternDct['text'] is False:
            self.nxsObj.itemPtrs.append( self)
            return    
             
        _displayField( self, self.nxsObj.outputBuffer)

    def display( self):

        self.ausgabe( None)

        for attr in self.attributes:
            attr.display()

        return

    def create( self, parent): 
        cfilter = _nexus.deflate_filter()
        cfilter.rate = 2

        try:
            field = parent.create_field( self.name, self.dtype, shape = self.shape, chunk = self.shape, filter=cfilter)
            field[...] = self.value
        except Exception as e:
            print( repr( e))
            print( "NxsField.create: failed for %s in %s " % (self.name, parent.name))
            print( "  dtype %s shape %s, value %s " % (self.dtype, self.shape, self.value))
            _sys.exit( 255)

        for attr in self.attributes:
            attr.create( field)

        return

    def search( self, patternDct):
        if argSupplied( patternDct['field']):
            if match( self.path, patternDct['field']):
                self.ausgabe(patternDct)
        elif argSupplied( patternDct['ndim']):
            if type( patternDct['ndim']) is str:
                ndim = _string.atoi( patternDct['ndim'])
            else:
                ndim = patternDct['ndim']
            if ndim == len( self.shape):
                self.ausgabe(patternDct)

        for attr in self.attributes:
            attr.search( patternDct)
        return

class NxsLink( _NxsItem):
    def __init__( self, parent, name, path, ltype, target_path):
        _NxsItem.__init__( self, parent, name, path)
        #
        # SOFT:     internal link
        # HARD:     stores data
        # EXTERNAL: link to external file
        #
        self.type   = ltype 
        #
        # type target_path: pni.io.nx._nx.nxpath
        #
        self.target_path = target_path
        self.attributes = []

        return 

    def ausgabe( self, patternDct): 

        #
        # when pointers are returned, always use fields, not links
        #

        self.nxsObj.outputBuffer.append( "%s %d Link: %s, parent: %s" % (self._someBlanks(), self.level, self.name, self.parent.name))
        self.nxsObj.outputBuffer.append( "%s      path:  %s" % (self._someBlanks(), self.path))
        self.nxsObj.outputBuffer.append( "%s      target_path:  %s" % (self._someBlanks(), self.target_path)) # +++ 25.10.2017

    def display( self):
        self.ausgabe( None)
        return

    def create( self, parent): 
        path = self.target_path
        #
        # 'SOFT' means internal link. in this casse path.filename has
        # to be cleared. For 'EXTERNAL' links the filename is used.
        #
        # example for a soft link which in inserted into NXDATA:
        #   tst_00151.nxs://scan/instrument/collection/d1_c01
        #
        if self.type is _nexus.nxlink_type.SOFT:
            #
            #
            path.filename = ""
        #
        _nexus.link( path.__str__(), parent, self.name)
        return

    def search( self, patternDct):
        if argSupplied( patternDct['field']):
            if match( self.path, patternDct['field']):
                self.ausgabe( patternDct)
        return

class NxsAttr( _NxsItem):
    def __init__( self, parent, name, path, dtype, shape, value):
        _NxsItem.__init__( self, parent, name, path)
        self.dtype = dtype
        self.dtype = dtype
        self.shape = shape
        self.value = value

        return 

    def ausgabe( self, patternDct):

        if patternDct and 'text' in patternDct and patternDct['text'] is False:
            self.nxsObj.itemPtrs.append( self)
            return    

        valString = "<noValue>"
        if hasattr( self, 'value'):
            valString = _prepareValue( str( self.value))

        self.nxsObj.outputBuffer.append( "%s %d Attr: %s, parent: %s, value: %s" % \
                                         (self._someBlanks(), self.level, self.name, self.parent.name, _prepareValue( self.value)))
        self.nxsObj.outputBuffer.append( "%s   path: %s " % (self._someBlanks(), self.path))

        return

    def display( self):
        self.ausgabe( None)
        return
            
    def create( self, parent):

        attrList = [attr.name for attr in parent.attributes]
        #
        # if the class is specified when creating a group, the NX_class 
        # attribute is automatically created
        #
        if self.name in attrList:
            return

        try:
            a = parent.attributes.create( self.name, self.dtype, shape = self.shape)
            a[...] = self.value
        except:
            print( "NxsAttr._create: failed to create %s in %s" % (self.name, parent.path))
            pass
        return

    def search( self, patternDct):
        #
        # path, e.g.: /scan:NXentry/program_name@scan_command
        #
        if argSupplied( patternDct['attr']):
            if match( self.path, patternDct['attr']):
                self.ausgabe(patternDct)

class _NxsObj():
    '''
    _NxsObj is instantiated by the nxsReader
    It contains
      - the rootGroup
      - pathDct which relates path names to _NxsItems
      - outputBuffer, a list of strings, containing the
        display/search output
      - itemPtrs, a list of fields or attributes, containing the search result
    '''
    def __init__( self, fileName):

        self.pathDct ={}
        self.outputBuffer = []
        self.itemPtrs = []
        self.rootGroup = None
        self.fileName = fileName
        self.match = match

        return

    def display( self):
        '''
        return a list of strings containing, groupd, fields, links and attributes
        '''
        self.outBuffer = []
        self.itemPtrs = []
        self.rootGroup.display()
        return self.outputBuffer

    def createFile( self, fileName):
        '''
        writes the object into a NeXus file
        '''
        new = _nexus.create_file( fileName, overwrite=True)

        self.rootGroup.create( new.root())

        new.close()
        return
        
    def search( self, **patternDct):
        ''' 
        keywords: 'group', 'field', 'attr', 'ndim', 'text'

        None:      --<keyword> supplied but no pattern
        'Missing': --<keyword> not supplied
        'text'      -- if 'text=True' a list of strings is returned, otherwise a list if NeXus items
        
        o = HasyUtils.nxsObj( 'someFile.nxs')

        o.search( group = None, text = True)                            
          return a list of strings containing all groups 
        o.search( group = None, field = None, attr = None, text = True)                            
          return a list of strings containing all groups, fields and attributes 
        o.search( group = "slit1', text = True)                         
          return a list of strings containing all groups with paths containing 'slit1' 
        o.search( field = None, text = True)             
          return a list of strings containing all fields
        o.search( ndim = 2, text = True)             
          return a list of strings containing all 2-dimensional fields, e.g. (21, 2048)
        o.search( field = None)
          return a list of pointers to all fields
        lst = o.search( field = '/scan:NXentry/instrument:NXinstrument/detector:NXdetector/collection:NXcollection/d1_c01')
          return a list containing the pointer to the fully qualified field, 
          lst[0].value contains the counter readings, numpy.ndarray
        lst = o.search( field = '/scan:NXentry/instrument:NXinstrument/collection:NXcollection/exp_dmy01')
          return a list containing the pointer to a fully qualified field
          lst[0].value contains the motor positions, numpy.ndarray
        lst = o.search( attr='/scan:NXentry/program_name@scan_command')  
          return a list containing the pointer to the attribute containing the scan command
          lst[0].value is a string
        '''
        #
        # the Dct may be incomplete because the funcion may 
        # has been called from some other function from outside
        #
        for elm in ('group', 'field', 'attr', 'name', 'ndim'):
            if elm not in patternDct:
                patternDct[ elm] = "Missing"
        if 'text' not in patternDct:
            patternDct[ 'text'] = False

        self.outputBuffer = []
        self.itemPtrs = []

        self.rootGroup.search( patternDct)

        if patternDct['text'] is False:
            return self.itemPtrs

        if not self.outputBuffer:
            self.outputBuffer = ["No match found"]
        return self.outputBuffer 

    def util( self, **patternDct):
        '''
        o.util( util = 'createtestfile')
        o.util( util = 'collectstatus')
        o.util( util = 'createintfield')
        o.util( util = 'createstringfield')
        '''
        if patternDct['util'] == 'createtestfile':
            self.fillTestData()
            lst = self.fileName.split( '.')
            newFile = lst[0] + 'test.' + lst[1]
            self.createFile( newFile)
        elif patternDct['util'] == 'collectstatus':
            self.collectStatus()
        elif patternDct['util'] == 'createintfield':
            targetGroup = self.pathDct['/']
            lst = [1, 3, 5, 7, 11, 13, 17, 19]
            newField = NxsField( targetGroup, "Primes", "/Primes", 'int64', (len(lst),), _np.array(lst))
            targetGroup.fields.append( newField)
        elif patternDct['util'] == 'createstringfield':
            targetGroup = self.pathDct['/']
            newField = NxsField( targetGroup, "StringField", "/StringField", 'string', (1,), "a string field")
            targetGroup.fields.append( newField)
        return

    def _findDoubles( self):
        ''' class: _NxsObj
        - parses the scan_command to find the scan motor
        - return a list of indices of identical motor positions
        - data belonging to these indices have to be deleted
        '''
        scanCommand = self.pathDct[ '/scan:NXentry/program_name@scan_command'].value

        lst = scanCommand.split()
        #
        # ascan exp_dmy01 0 10 10 0.1
        # dscan exp_dmy01 -5 5 10 0.1
        #
        if lst[0] == 'ascan' or \
           lst[0] == 'ascan_repeat' or \
           lst[0] == 'a2scan' or \
           lst[0] == 'a2scan_repeat' or \
           lst[0] == 'a3scan' or \
           lst[0] == 'a3scan_repeat' or \
           lst[0] == 'a4scan' or \
           lst[0] == 'dscan' or \
           lst[0] == 'dscan_repeat' or \
           lst[0] == 'd2scan' or \
           lst[0] == 'd3scan' or \
           lst[0] == 'hscan' or \
           lst[0] == 'kscan' or \
           lst[0] == 'lscan':
            scanMotor = lst[1]
        else:
            print( "NeXusObj._findDoubles: %s is not supported yet" % lst[0])
            return False

        motorPath = "/scan:NXentry/instrument:NXinstrument/collection:NXcollection/" + scanMotor
        if motorPath not in self.pathDct:
            print( "NeXusObj._findDoubles: %s not in the dictionary" % motorPath)
            return False

        posArr = self.pathDct[ motorPath].value

        iDoubles = []
        for i in range( len( posArr) - 1):
            if posArr[i] == posArr[i + 1]:
                iDoubles.append( i)

        return iDoubles

    def findFields( self, rank): 
        ''' class: _NxsObj
        returns a list of references to fields containing data of the specified rank
        0: (21,)
        1: (21, 1024)
        2: (21, 195, 487)
        '''
        arr = []
        for elm in list(self.pathDct.keys()):
            if not hasattr( self.pathDct[elm], 'shape'):
                continue
            #
            # mind: attributes can also have shapes, but they don't an attributs array
            #
            if not hasattr( self.pathDct[elm], 'attributes'):
                continue
            if rank == 0:
                if len( self.pathDct[elm].shape) == 1 and self.pathDct[elm].shape[0] > 1:
                    arr.append( self.pathDct[elm])
            elif rank == 1:
                if len( self.pathDct[elm].shape) == 2 and self.pathDct[elm].shape[0] > 1:
                    arr.append( self.pathDct[elm])
            elif rank == 2:
                if len( self.pathDct[elm].shape) == 3 and self.pathDct[elm].shape[0] > 1:
                    arr.append( self.pathDct[elm])
            else:
                raise Exception( "NeXusObj._findField(rank): rank out of range %d, (0,1,2)" % rank)

        return arr
        
    def _purgeCounters( self, fieldsCounters):
        ''' 
        class: _NxsObj
        '''
        for field in fieldsCounters:
            length = field.value.shape[0] - len( self.iDoubles)
            if  length <= 0:
                raise Exception( "_purgeCounters: %s, len(Idoubles) >= len( field.name): %d" % \
                                 (field.name, field.value.shape[0]))
            temp = _np.zeros( length, dtype = field.value.dtype)
            j = 0
            for i in range(field.value.shape[0]):
                if i in self.iDoubles:
                    continue
                temp[j] = field.value[i]
                j += 1
            field.value = temp
            field.shape = temp.shape
        return 

    def _purgeMCAs( self, fieldsMCAs):
        ''' 
        class: _NxsObj
        '''
        for field in fieldsMCAs:
            length = field.value.shape[0] - len( self.iDoubles)
            if  length <= 0:
                raise Exception( "_purgeMCAs: len(Idoubles) >= len( field.name): %d" % \
                                 (field.name, field.value.shape[0]))
            temp = _np.zeros( length*field.value.shape[1], dtype = field.value.dtype).reshape( length, field.value.shape[1])
            j = 0
            for i in range(field.value.shape[0]):
                if i in self.iDoubles:
                    continue
                temp[j] = field.value[i,...]
                j += 1
            field.value = temp
            field.shape = temp.shape
        return 

    def _purgeImages( self, fieldsImages):
        ''' 
        class: _NxsObj
        '''
        for field in fieldsImages:
            length = field.value.shape[0] - len( self.iDoubles)
            if  length <= 0:
                raise Exception( "_purgeImages: len(Idoubles) >= len( field.name): %d" % \
                                 (field.name, field.value.shape[0]))
            temp = _np.zeros( length*field.value.shape[1]*field.value.shape[2], 
                             dtype = field.value.dtype).reshape( length, field.value.shape[1], field.value.shape[2])
            j = 0
            for i in range(field.value.shape[0]):
                if i in self.iDoubles:
                    continue
                temp[j] = field.value[i][...]
                j += 1
            field.value = temp
            field.shape = temp.shape
        return 
                
    def purge( self):
        ''' class: _NxsObj
        find identical motor positions, remove them together with 
        associated data
        '''

        if not self.collectStatus():
            raise Exception( "nxsReader.purge: %s hasn't been collected yet" % fileName)

        self.iDoubles = self._findDoubles()
        if len( self.iDoubles) == 0:
            if flagTTY: print( "NeXusObj.purge: nothing to purge")
            return True


        fieldsCounters = self.findFields( 0)
        fieldsMCAs = self.findFields( 1)
        fieldsImages = self.findFields( 2)

        if len( fieldsCounters) > 0:
            self._purgeCounters( fieldsCounters)

        if len( fieldsMCAs) > 0:
            self._purgeMCAs( fieldsMCAs)

        if len( fieldsImages) > 0:
            self._purgeImages( fieldsImages)

        targetGroup = self.pathDct['/']
        shape = len(self.iDoubles), 
        tempArr = _np.array( self.iDoubles)
        newField = NxsField( targetGroup, "PurgedIndices", "/PurgedIndices", 'int64', shape, tempArr)
        self.rootGroup.fields.append( newField)

        return True

    def fillTestData( self):
        ''' 
        fills all 1D and 2D fields with consecutive numbers to be
        used for testing purge, not in 0D field because then
        we override the motor positions
        '''
        fields = self.findFields( 1) + self.findFields( 2)
        
        #
        # fill the mca spectra and images with numbers like
        # the scan index
        #
        for field in fields:
            for i in range( field.shape[0]):
                #
                # MCAs and Images
                #
                if len( field.shape) > 1:
                    field.value[i][...] = i
        return

    #
    # 1) find all 'postrun' fields in 'NXcollection' groups.
    # 2) for each 'postrun' field check the 'data' field which should be in
    # the same group as the 'NXcollection' group
    #   a) if 'data' field does not exist it means that data was not collected
    #  (see also 3))
    #   b) if the content of the 'postrun' field does not correspond to the
    # data field content, i.e. the 'data' field has less rows than the number
    # of file names in the postrun field (collection process was cancel or
    # there where missing files) it means that data was not fully collected
    #
    # 3) if the postrun field has the 'fieldname' attribute that means
    # the data will be collected into the field defined by the 'fieldname'
    # value (not 'data' field). Than one has to perform the 2) replacing
    # 'data' by the new name from the 'fieldname' attribute.
    #
    def collectStatus( self):
        status = True
        #
        # postrunField: /scan:NXentry/instrument:NXinstrument/pilatus:NXdetector/collection:NXcollection/postrun
        #
        postrunFields = self.search( field = 'collection:NXcollection/postrun', text = False)
        for field in postrunFields:
            #
            # value: /home/kracht/Misc/IVP/temp/ppt... tus/pptest_00311_%05d.cbf:0:13
            #
            lst = field.value.split(':')
            if len( lst) < 2:
                if flagTTY: 
                    print( "collectStatus: failed to split: <%s>" % field.value)
                    print( "  path %s" % field.path)
                continue
            ndata = _string.atoi(lst[-1]) - _string.atoi(lst[-2]) + 1
            #
            #  sPath: /scan:NXentry/instrument:NXinstrument/pilatus:NXdetector/data
            #  if this field is missing, the collections process hasn't been done yet.
            #
            sPath = field.parent.parent.path + '/data'
            dataFields = self.search( field = sPath, text = False)
            if len(dataFields) == 0:
                if flagTTY: print( "collectStatus: not found %s" % sPath)
                return False
            if len(dataFields) > 1:
                if flagTTY: print( "collectStatus: too many matching fields for %s %s" % (sPath, dataFields))
                return False
            # print 'dataField', dataFields[0].path, dataFields[0].shape
            if dataFields[0].shape[0] != ndata:
                if flagTTY: print( "collectStatus: ndata %d and shape[0] %d do not match" % (ndata, dataFields[0].shape[0]))
                status = False
        return status

def _NxsCrawler( fileGroup, group, nxsObj, level):
    '''
    fileNode is a group in the NeXus file
    group    is a group in the nxsObj
             - already filled with name and path
    '''
    for attr in fileGroup.attributes:
        group.attributes.append( NxsAttr(group, attr.name, attr.path, attr.dtype, attr.shape, attr.read()))

    fileLinks = _nexus.get_links( fileGroup)

    for fileLink in fileLinks:
        if fileLink.type == _nexus.nxlink_type.HARD:
            newFileGroup = fileLink.resolve()
            if isinstance( newFileGroup, _nexus.nxgroup): 
                nxsClass = _nexus.get_class( newFileGroup)
                newGroup = NxsGroup( group, newFileGroup.name, newFileGroup.path, nxsClass)
                group.groups.append( newGroup)
                _NxsCrawler( newFileGroup, newGroup, nxsObj, level + 1)
            elif isinstance( newFileGroup, _nexus.nxfield):
                newField = NxsField( group, newFileGroup.name, newFileGroup.path, 
                                     newFileGroup.dtype, newFileGroup.shape, newFileGroup.read())
                for attr in newFileGroup.attributes:
                    newAttr = NxsAttr( newField, attr.name, attr.path, attr.dtype, attr.shape, attr.read())
                    newField.attributes.append( newAttr)
                group.fields.append( newField)
        else:
            newLink = NxsLink( group, fileLink.name, fileLink.path, fileLink.type, fileLink.target_path)
            group.links.append( newLink)
            
    return

    
def nxsReader( fileName):
    '''
    Input:   name of a NeXus file (extension .nxs)
    Returns: obj (class _NxsObj) 
 
    'nxsreader' is a command line interface to this function.
    It allows to inspect the contents of a NeXus file
    and to extract certain field.
    '''
    try:
        f = _nexus.open_file( fileName, True)        
    except Exception as e:
        raise Exception( "nxsReader: failed to open %s" % fileName)

    nxsObj = _NxsObj( fileName)
    fileNode = f.root()
    nxsClass = _nexus.get_class( fileNode)
    level = 1    
    rootGroup = NxsGroup( None, fileNode.name, fileNode.path, nxsClass)
    rootGroup.nxsObj = nxsObj
    rootGroup.nxsObj.pathDct[fileNode.path] = rootGroup
    nxsObj.rootGroup = rootGroup
    _NxsCrawler( fileNode, rootGroup, nxsObj, level)
    f.close()
    return nxsObj

def _displayField( field, lines):
    '''
    lines: outputBuffer
    '''
    flag = False
    if lines is None:
        flag = True
        lines = []

    maxLines = 30
    blanks = " ".join(" " for i in range(field.level))
    lines.append( "%s %d Field: name: %s, shape: %s, dtype: %s" % \
        ( blanks, field.level, field.name, str( field.shape), field.dtype))
    lines.append( "%s    path:  %s" %( blanks, field.path))

    if len(field.shape) == 1:
        length = field.shape[0]
        #
        # case (1,)
        #
        if  length == 1:
            lines.append( "%s    value: %s" % ( blanks, _prepareValue( field.value)))
        #
        # (28,)
        #
        else:
            if length < maxLines:
                step = 10
                if field.dtype == 'float64':
                    step = 5
                start = 0
                stop = step
                while length > step:
                    lines.append( "%s    value[%d:%d]: %s" % (blanks, start, stop, str(field.value[start:stop])))
                    length = length - step
                    start = start + step
                    stop = stop + step
                if length > 0:
                    stop = start + length
                    lines.append( "%s    Value[%d:%d]: %s" % (blanks, start, stop, str(field.value[start:stop])))
                else:
                    lines.append( "%s    value: %s" % (blanks, _prepareValue( field.value)))
            else:
                lines.append( "%s    value[:%d): %s" % (blanks, maxLines/2, _prepareValue( field.value[:maxLines/2])))
                lines.append( "%s    value[%d:): %s" % (blanks, (length - maxLines/2), _prepareValue( field.value[maxLines/2:])))
    #            
    # (28, 2048)
    # (28, 195, 287)
    #            
    else:
        iScan = field.shape[0]
        if iScan < maxLines:
            for i in range( iScan):
                lines.append( "%s    value[%d][...]: %s" % ( blanks, i, _prepareValue( field.value[i][...])))
        else:
            for i in range( maxLines/2):
                lines.append( "%s    value[%d][...]: %s" % ( blanks, i, _prepareValue( field.value[i][...])))
            for i in range( iScan - maxLines/2, iScan):
                lines.append( "%s    value[%d][...]: %s" % ( blanks, i, _prepareValue( field.value[i][...])))
    if flag:
        for line in lines: print( line)

    return


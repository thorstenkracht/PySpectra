#!/usr/bin/env python
'''
avoid PyQt4 vs. PyQt5 conflict: is import PySpectra PyQt4 is
automatically imported. this conflicts with PyQT5 from the
MacroServer.
'''

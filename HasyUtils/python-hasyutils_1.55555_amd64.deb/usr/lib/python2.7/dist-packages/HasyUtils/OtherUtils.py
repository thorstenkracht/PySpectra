#!/usr/bin/env python
#   
from . import TgUtils
import os as _os
import sys as _sys
import importlib as _importlib
import datetime as _datetime
import h5py as _h5py
import numpy as _np
import time as _time
#
#
#
def getHostVersionSardana( host = None):
    """
    check <host> for the sardana python version

    returns 
      2, if python-sardana is installed
      3, if python3-sardana is installed

    use HasyUtils.getVersionSardana() for the local version
    """
    isP2 = False
    isP3 = False

    if host is None: 
        raise ValueError( "OtherUtils.getHostVersionSardana: use HasyUtils.getVersionSardana() for the local version")

    argout = _os.popen('ssh root@%s "dpkg --status python3-sardana 2> /dev/null || echo failedfailed"' % host).read()
    if argout.find( 'failedfailed') != -1:
        isP3 = True
    argout = _os.popen('ssh root@%s "dpkg --status python-sardana 2> /dev/null || echo failedfailed"' % host).read()
    if argout.find( 'failedfailed') != -1:
        isP2 = True

    if isP2 and isP3:
        raise ValueError( "OtherUtils.getHostVersionSardana: found python-sardana AND python3-sardana")
    if not isP2 and not isP3:
        raise ValueError( "OtherUtils.getHostVersionSardana: found neither python-sardana nor python3-sardana")
    if isP3: 
        argout = 3
    else: 
        argout = 2
    return argout

#
# a copy of this function is in 
#   /home/kracht/Misc/pySpectra/PySpectra/misc/utils.py
#
def assertProcessRunning(processName): 
    """
    returns ( True, False), if processName is running
    returns ( False, False), if the processName (the file) does not exist
    returns ( True, True), if processName was launched successfully
    returns ( False, False), if the launch failed

    example: 
      (status, wasLaunched) = HasyUtils.assertProcessRunning( '/usr/bin/pyspMonitor.py')

  """
    #
    # see, if the pyspMonitor process exists. Otherwise launch it
    #
    if findProcessByName( processName): 
        return (True, False)

    if not _os.path.isfile( processName):
        print( "OtherUtils.assertProcessRunning: %s does not exist" % processName)
        return (False, False)
        
    if _os.system( "%s &" % processName):
        print( "OtherUtils.assertProcessRunning: failed to launch %s" % processName)
        return (False, False)

    count = 0
    while 1: 
        count += 1
        if findProcessByName( processName): 
            #
            # we need some extra time. The process appears in
            # the process list but is not active
            #
            _time.sleep( 3) 
            return (True, True)
        _time.sleep( 0.1)
        if count > 15:
            print( "OtherUtils.assertProcessRunning: %s does not start in time " % processName)
            return ( False, False)

    return (True, True)


#
# a copy of this function is in 
#   /home/kracht/Misc/pySpectra/PySpectra/misc/utils.py
#
def findProcessByName( cmdLinePattern):
    """
    returns True, if the process list contains a command line
    containing the pattern specified

    cmdLinePattern, e.g.: 'pyspMonitor.py' 
      which matches ['python', '/usr/bin/pyspMonitor.py']

    """
    import psutil

    for p in psutil.process_iter():
        lst = p.cmdline()
        if len( lst) == 0:
            continue
        for elm in lst: 
            if elm.find( cmdLinePattern) != -1:
                return True
    return False

def checkHostOnline( host): 
    '''
    returns True, if the host replies to ping, 
    includes checkHostExists()
    '''

    if not checkHostExists( host):
        return False

    lines = _os.popen( "ping -c 1 -w 1 -q %s 1>/dev/null 2>&1 || echo offline" % host).readlines()
    if 'offline\n' in lines:
        return False
    return True

def checkHostExists( host): 
    '''
    returns True, if the host name resolves (exist)
    '''
    import socket

    try: 
        socket.gethostbyname( host)
    except socket.error: 
        return False

    return True

class _MyAlarm(Exception):
    pass

def alarm_handler(signum, frame):
    raise _MyAlarm

def checkHostRootLogin( host): 
    '''
    - returns True, if the host replies to a root login (executing 'hostname')
    - the time-out is 3 seconds
    - includes checkHostOnline()
    '''
    import subprocess 
    import signal

    if not checkHostOnline( host): 
        #print( "OtherUtils.checkHostRootLogin: %s is not online" % host)
        return False

    signal.signal(signal.SIGALRM, alarm_handler)

    try: 
        #
        # the ssh authentication flas make this thing running also from cronjobs
        #
        p = subprocess.Popen( ['ssh', "-x", "-o", "PubkeyAuthentication=yes",  "-o", 
                               "GSSAPIAuthentication=no", "root@%s" % host,  "hostname > /dev/null" ])
    except Exception as e:
        print( "checkHostRooLogin: exception occured %s" % repr( e))
    signal.alarm( 3)

    try: 
        p.wait()
        signal.alarm(0)
    except _MyAlarm:
        p.kill()
        p.wait()
        return False

    return True

def doty2datetime(doty, year = None):
    """
    Convert the fractional day-of-the-year to a datetime structure.
    The default year is the current year.

    Example: 
      a = doty2datetime( 28.12)
      m = [ 'Jan', 'Feb', 'Mar', 'Aptr', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
      print( "%s %d, %02d:%02d" % (m[ a.month - 1], a.day, a.hour, a.minute))
      --> Jan 29, 02:52
    """
    if year is None:
        now = _datetime.datetime.now()
        year = now.year
    dotySeconds = doty*24.*60.*60
    boy = _datetime.datetime(year, 1, 1)
    return boy + _datetime.timedelta(seconds=dotySeconds)

def readHostList( fName):
    '''
    read a host list
      - comment lines and empty lines are ignored
    '''
    if not _os.path.isfile( fName):
        raise Exception( "OtherUtils.readHostList", "%s does not exist" % fName)
    
    try:
        inp = open( fName, 'r')
    except Exception as e:
        raise Exception( "OtherUtils.readHostList", "failed to optn %s" %fName)

    hosts = []
    for line in inp.readlines():
        if line.strip().find( '#') == 0:
            continue
        if len( line.strip()) == 0:
            continue
        hosts.append( line.strip())
    inp.close()

    return hosts

def fioAddsToFile( fileName):
    '''
    creates fileName filled with a list and/or a dict from  /online_dir/fioAdds.py
    '''
    import imp

    if _os.path.exists( fileName):
        raise Exception( "fioAddsToFile", " %s exists already" % fileName)

    (fioList, fioDict) = getFioAdds()

    if fioList is None and fioDict is None:
        raise Exception( "fioAddsToFile", " no list, no dict from fioAdds.py")

    fd = open( fileName, 'w')

    fd.write("!\n! Comments\n!\n%c\n")
    
    if not fioList is None:
        for elm in fioList:
            fd.write( "%s\n" % (str(elm)))
    fd.flush()
    #
    # write the parameter section, including the motor positions, if needed
    #
    fd.write("!\n! Parameter\n!\n%p\n")
    fd.flush()
    if not fioDict is None:
        for k in sorted( fioDict.keys()):
            fd.write( "%s = %s\n" % (str(k), str(fioDict[k])))
    fd.close()

    return True

def getFioAdds():
    '''
    returns fioList, fioDict from  FioAdditions (MacroServer environment variable
    '''
    fName = TgUtils.getEnv( "FioAdditions")
    if fName is None:
        raise Exception( "getFioAdds", " MacroServer environment variable FioAdditions does not exit")

    #
    # fName      /online_dir/fioAdds.py
    # dirName    /online_dir
    # baseName   fioAdds.py
    # prefixName fioAdds
    #
    dirName = _os.path.dirname( fName)
    baseName = _os.path.basename( fName)
    if baseName.find( '.py') > 0:
        prefixName = baseName.rpartition('.')[0]
    if dirName not in _sys.path:
        _sys.path.insert( 0, dirName)
    try:
        mod = _importlib.import_module( prefixName)
        fioAdds = mod.main()
    except Exception as e:
        raise Exception( "getFioAdds", " failed to import %s, %s" % (fName, repr( e)))
    fioList = None
    fioDict = None
    #
    # allowed: list, dict, [list], [dict], [list, dict], [dict, list]
    #
    if type( fioAdds) is dict:
        fioDict = fioAdds
    elif type( fioAdds) is list:
        if len(fioAdds) == 1:
            if type(fioAdds[0]) is list:
                fioList = fioAdds[0]
            elif type( fioAdds[0]) is dict:
                fioDict = fioAdds[0]
            else:
                fioList = fioAdds
        elif len( fioAdds) != 2:
            fioList = fioAdds
        else:
            if type( fioAdds[0]) is list:
                fioList = fioAdds[0]
                if not fioAdds[1] is dict:
                    raise Exception( "fioAddsToFile", " second list element expected to be a dict")
                fioDict = fioAdds[1]
            elif type( fioAdds[0]) is dict:
                fioDict = fioAdds[0]
                if not type( fioAdds[1]) is list:
                    raise Exception( "fioAddsToFile", " second list element expected to be a list")
                fioList = fioAdds[1]
            else:
                fioList = fioAdds
    else:
        raise Exception( "fioAddsToFile", " expecting list or dict")

    return fioList, fioDict


class nxsFile(): 
    '''
    an interface to .nxs files as they are created by Jan Kotanskies
    NeXus framework
    '''
    def __init__( self, fileName): 

        if not _os.path.exists( fileName):
            raise Exception( "OtherUtils.nxsFile.__init__ %s does not exist" % self.fileName)
            
        self.fileName = fileName
        try: 
            self.fh = _h5py.File( self.fileName, 'r')
        except Exception as e: 
            print( "OtherUtils.nxsFile.__init__: error %s " % self.fileName)
            print( repr(e))
            raise Exception( "OtherUtils.nxsFile.__init__", " failed to open" % self.fileName)

        self.depth = 0

    def get1DData( self): 
        '''
        returns a dictionary like
        {
        u'eh_c01': <type 'numpy.ndarray'>,
        u'eh_t01': <type 'numpy.ndarray'>,
        u'exp_dmy01': <type 'numpy.ndarray'>,
        u'ipetra': <type 'numpy.ndarray'>,
        u'point_nb': <type 'numpy.ndarray'>,
        u'sig_gen': <type 'numpy.ndarray'>,
        u'timestamp': <type 'numpy.ndarray'>,
        }
        '''
        ret = self.crawler( "1D")
        argout = {}
        for elm in ret:
            #
            # /scan/data/eh_c01 -> eh_c01
            #
            shortName = elm[0].split( '/')[-1]
            argout[ shortName] = elm[1]
            
        return argout

    def getMcaData( self): 
        '''
        '''
        argout = None
        for elm in list(self.fh[ 'scan'][ 'data'].keys()):
            try:
                temp = self.fh[ 'scan'][ 'data'][ elm]
            except Exception as e:
                print( "OtherUtils.nxsFile.get1DData: error %s" % elm)
                print( repr(e))
                continue
            #
            # len( shape) == 2 selects MCA data
            #
            if len( self.fh[ 'scan'][ 'data'][ elm].shape) != 2:
                continue
            longName = self.fh[ 'scan'][ 'data'][ elm].name
            shortName = longName.split( '/')[-1]
            if shortName.lower().find( "mca") == -1:
                continue
            dset = self.fh[ 'scan'][ 'data'][ elm]
            #
            # /scan/data/eh_c01 -> eh_c01
            #
            argout = dset[()]
            break

        return argout

    def getMotorName( self):
        '''
        returns the motorName.
        
        it is found in fileHandle[ 'scan'][ 'program_name'].attrs[ 'scan_command']
        e.g.: ascan exp_dmy01 0.0 1.0 20 0.1'
        '''
        try:
            temp = self.fh[ 'scan'][ 'program_name'].attrs[ 'scan_command'][0]
        except Exception as e:
            print( "OtherUtils.nxsFile.getMotorName: failed")
            print( repr(e))
            return None
        
        lst = temp.split()
        if lst[0] == 'ascan': 
            argout = lst[1]
        elif lst[0] == 'dscan': 
            argout = lst[1]
        else:
            print( "OtherUtils.nxsFile: failed to identify scan type %s " % lst[0])
            argout = None

        return argout

    def getScanCommand( self): 
        '''
        returns the scan command
        '''
        try:
            argout = self.fh[ 'scan'][ 'program_name'].attrs[ 'scan_command'][0]
        except Exception as e:
            print( "OtherUtils.nxsFile.getScanCommand: failed")
            print( repr(e))
            return None
        
        return argout
    
    def printAttrs( self, node): 

        if self.mode.upper() != "DISPLAY":
            return 

        print( "%s     Attributes for %s" % ( "  " * self.depth, node.name))
        for attr in list( node.attrs.keys()):
            if attr == "nexdatas_source":
                print( "     %s  %s: %s ..." % ( "  " * self.depth, attr, node.attrs[ attr][0][:30]))
            else: 
                print( "     %s  %s: %s" % ( "  " * self.depth, attr, node.attrs[ attr]))

    def printDataset( self, node): 

        if self.mode.upper() != "DISPLAY":
            return 

        print( "%s   dtype %s, ndim %d, size %d, shape %s" % ( "  " * self.depth,
                                                              str(node.dtype), 
                                                              node.ndim, node.size, str( node.shape)))
        dset = node[()]
        print( "%s   dset: %s" % ( "  " * self.depth, repr( type(dset))))

    def isNxData( self, node): 
        '''
        return True, if the parent, e.g. /scan/data, is NXdata,
        which identifies datasets to be displayed
        '''

        try:
            if 'NXdata' in list( node.parent.attrs.values()):
                return True
        except Exception as e:
            print( "OtherUtils.nxsFile.isNxData: error")
            print( repr(e))
            return False

        return False

    def selectDataset( self, dset): 
        '''
        this function is called for datasets. it fill the argout
        with selected datasets.
        '''
        if self.mode.upper() == "DISPLAY": 
            return False

        if len( dset.shape) != 1: 
            return False

        if not dset.dtype == _np.float64:
            return False

        if not self.isNxData( dset):
            return False

        self.argout.append( ( dset.name, dset[()]))

        return True
        
    def crawler( self, mode = None): 
        '''
        mode: 
          None: display the file contents
          "1D": return a list of tuples [ ('/scan/instrument/collection/eh_c01', dataCol), ...]
        '''
        if mode is None:
            mode = "Display"
        self.mode = mode
        
        if self.mode.upper() == "DISPLAY":
            print( "%s %s (%s)" % ("  " * self.depth, self.fh.name, self.fh.__class__))
            self.printAttrs( self.fh)

        self.argout = []
        self.crawlerRecursive( self.fh)
        return self.argout

    def crawlerRecursive( self, group): 
        self.depth += 1
        #print( "group %s %s" % (group.name, repr( dir( group))))
        for k in list( group.keys()): 
            l = group.get( k, getlink=True)
            #
            # eh_c01 may appear in 
            #   /scan/data as a softlink
            #   /scan/instrument/collection as a hardlink 
            #
            if isinstance( l, _h5py._hl.group.SoftLink): 
                #
                # see, if the SoftLink is pointing somewhere
                #
                flagExists = l.path in self.fh
                if not flagExists:
                    if self.mode.upper() == "DISPLAY":
                        print( "%s %s Softlink to %s target does not exist" % ("  " * self.depth, k, l.path))
                    continue
                lnk = "SoftLink to %s" % (l.path)
            elif isinstance( l, _h5py._hl.group.HardLink): 
                lnk = "HardLink"
            else:
                lnk = "UnknownLink"

            if self.mode.upper() == "DISPLAY":
                if isinstance( group[k], _h5py._hl.group.Group):
                    print( "%s *** %s %s, %s" % ("  " * self.depth, k, group[k].__class__, lnk))
                else: 
                    print( "%s %s %s, %s" % ("  " * self.depth, k, group[k].__class__, lnk))

            if isinstance( group[k], _h5py._hl.dataset.Dataset):
                self.printDataset( group[k])
                self.selectDataset( group[k])
            self.printAttrs( group[ k])

            if isinstance( group[k], _h5py._hl.group.Group):
                self.crawlerRecursive( group[k])

        self.depth -= 1

def shebang2P3( dirName = None): 
    """
    changes the shebang of all python files of the current
    direectory for dirName to 
      /usr/bin/python3 or /usr/bin/env python3 
    depending on the initial state
    """
    import glob
    if dirName is not None: 
        _os.chdir( dirName)

    for file in glob.glob( '*.py'):
        print( "changing %s " % file)
        # -n suppress default output
        _os.system( "sed -n 1p %s" % file)
        # -i in place
        _os.system( "sed -i 's/^#!\/usr\/bin\/env python\s*$/#!\/usr\/bin\/env python3/g' %s" % file)
        _os.system( "sed -i 's/^#!\/usr\/bin\/python\s*$/#!\/usr\/bin\/python3/g' %s " % file)
        _os.system( "sed -n 1p %s" % file)

    return 

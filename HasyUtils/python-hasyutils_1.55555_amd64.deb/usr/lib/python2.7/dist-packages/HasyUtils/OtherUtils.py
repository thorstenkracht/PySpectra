#!/usr/bin/env python

import TgUtils
import os as _os
import sys as _sys
import importlib as _importlib
import datetime as _datetime

def checkHostOnline( host): 
    '''
    returns True, if the host replies to ping, 
    includes checkHostExists()
    '''

    if not checkHostExists( host):
        return False

    lines = _os.popen( "ping -c 1 -w 1 -q %s 1>/dev/null 2>&1 || echo offline" % host).readlines()
    if 'offline\n' in lines:
        return False
    return True

def checkHostExists( host): 
    '''
    returns True, if the host name resolves (exist)
    '''
    import socket

    try: 
        socket.gethostbyname( host)
    except socket.error: 
        return False

    return True

class _MyAlarm(Exception):
    pass

def alarm_handler(signum, frame):
    raise _MyAlarm

def checkHostRootLogin( host): 
    '''
    - returns True, if the host replies to a root login (executing 'hostname')
    - the time-out is 3 seconds
    - includes checkHostOnline()
    '''
    import subprocess 
    import signal

    if not checkHostOnline( host): 
        #print "OtherUtils.checkHostRootLogin: %s is not online" % host
        return False

    signal.signal(signal.SIGALRM, alarm_handler)

    try: 
        #
        # the ssh authentication flas make this thing running also from cronjobs
        #
        p = subprocess.Popen( ['ssh', "-x", "-o", "PubkeyAuthentication=yes",  "-o", 
                               "GSSAPIAuthentication=no", "root@%s" % host,  "hostname > /dev/null" ])
    except Exception, e:
        print "checkHostRooLogin: exception occured", repr( e)
    signal.alarm( 3)

    try: 
        p.wait()
        signal.alarm(0)
    except _MyAlarm:
        p.kill()
        p.wait()
        return False

    return True

def doty2datetime(doty, year = None):
    """
    Convert the fractional day-of-the-year to a datetime structure.
    The default year is the current year.

    Example: 
      a = doty2datetime( 28.12)
      m = [ 'Jan', 'Feb', 'Mar', 'Aptr', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
      print "%s %d, %02d:%02d" % (m[ a.month - 1], a.day, a.hour, a.minute)
      --> Jan 29, 02:52
    """
    if year is None:
        now = _datetime.datetime.now()
        year = now.year
    dotySeconds = doty*24.*60.*60
    boy = _datetime.datetime(year, 1, 1)
    return boy + _datetime.timedelta(seconds=dotySeconds)

def readHostList( fName):
    '''
    read a host list
      - comment lines and empty lines are ignored
    '''
    if not _os.path.isfile( fName):
        raise Exception( "OtherUtils.readHostList", "%s does not exist" % fName)
    
    try:
        inp = open( fName, 'r')
    except Exception, e:
        raise Exception( "OtherUtils.readHostList", "failed to optn %s" %fName)

    hosts = []
    for line in inp.readlines():
        if line.strip().find( '#') == 0:
            continue
        if len( line.strip()) == 0:
            continue
        hosts.append( line.strip())
    inp.close()

    return hosts

def fioAddsToFile( fileName):
    '''
    creates fileName filled with a list and/or a dict from  /online_dir/fioAdds.py
    '''
    import imp

    if _os.path.exists( fileName):
        raise Exception( "fioAddsToFile", " %s exists already" % fileName)

    (fioList, fioDict) = getFioAdds()

    if fioList is None and fioDict is None:
        raise Exception( "fioAddsToFile", " no list, no dict from fioAdds.py")

    fd = open( fileName, 'w')

    fd.write("!\n! Comments\n!\n%c\n")
    
    if not fioList is None:
        for elm in fioList:
            fd.write( "%s\n" % (str(elm)))
    fd.flush()
    #
    # write the parameter section, including the motor positions, if needed
    #
    fd.write("!\n! Parameter\n!\n%p\n")
    fd.flush()
    if not fioDict is None:
        for k in sorted( fioDict.keys()):
            fd.write( "%s = %s\n" % (str(k), str(fioDict[k])))
    fd.close()

    return True

def getFioAdds():
    '''
    returns fioList, fioDict from  FioAdditions (MacroServer environment variable
    '''
    fName = TgUtils.getEnv( "FioAdditions")
    if fName is None:
        raise Exception( "getFioAdds", " MacroServer environment variable FioAdditions does not exit")

    #
    # fName      /online_dir/fioAdds.py
    # dirName    /online_dir
    # baseName   fioAdds.py
    # prefixName fioAdds
    #
    dirName = _os.path.dirname( fName)
    baseName = _os.path.basename( fName)
    if baseName.find( '.py') > 0:
        prefixName = baseName.rpartition('.')[0]
    if dirName not in _sys.path:
        _sys.path.insert( 0, dirName)
    try:
        mod = _importlib.import_module( prefixName)
        fioAdds = mod.main()
    except Exception, e:
        raise Exception( "getFioAdds", " failed to import %s, %s" % (fName, repr( e)))
    fioList = None
    fioDict = None
    #
    # allowed: list, dict, [list], [dict], [list, dict], [dict, list]
    #
    if type( fioAdds) is dict:
        fioDict = fioAdds
    elif type( fioAdds) is list:
        if len(fioAdds) == 1:
            if type(fioAdds[0]) is list:
                fioList = fioAdds[0]
            elif type( fioAdds[0]) is dict:
                fioDict = fioAdds[0]
            else:
                fioList = fioAdds
        elif len( fioAdds) != 2:
            fioList = fioAdds
        else:
            if type( fioAdds[0]) is list:
                fioList = fioAdds[0]
                if not fioAdds[1] is dict:
                    raise Exception( "fioAddsToFile", " second list element expected to be a dict")
                fioDict = fioAdds[1]
            elif type( fioAdds[0]) is dict:
                fioDict = fioAdds[0]
                if not type( fioAdds[1]) is list:
                    raise Exception( "fioAddsToFile", " second list element expected to be a list")
                fioList = fioAdds[1]
            else:
                fioList = fioAdds
    else:
        raise Exception( "fioAddsToFile", " expecting list or dict")

    return fioList, fioDict

    


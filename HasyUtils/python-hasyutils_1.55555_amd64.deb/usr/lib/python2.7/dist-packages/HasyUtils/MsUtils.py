#!/usr/bin/env python
'''
this file contains the helper functions for the MacroServer
'''
import PyTango as _PyTango 
from . import TgUtils
import os as _os
import imp as _imp
import sys as _sys
import math as _math

def prepareDetectorAttrs( macro, name = "pilatus", rootDir = "/ramdisk", nbFrames = 1):
    '''
      prepareDetectorAttrs() uses the input arguments and the MacroServer
      environment variables ScanFile and ScanID to set these detector attributes:
        FileDir|SaveFilePath|saving_directory: /<rootDir>/<scanName>/<detectorName>
                                               /ramdisk/au_01390/pilatus
        FilePrefix|saving_prefix:  <scanName>
                                   au_01390
        NbFrames|FrameNumbers|acq_nb_frames: nbFrames

        FileStartNum|saving_next_number:     0
     
     This directory is created: 
        rootDir + "/" + scanName + "/" + detectorName
        /gpfs/current/raw/au_00001/pilatus

     As a safety measure, rootDir is compared with FileDir|SaveFilePath|saving_directory. 
     An error is thrown, if the values are incompatible. Both
     strings are compatible, if FileDir starts with rootDir

     So far Pilatus, Lambda, Kromo and Lima (Andor) servers are supported
    '''
    detectorName = name

    scan_file = macro.getEnv("ScanFile")
    if type(scan_file).__name__ == 'list':
        scan_file = scan_file[0]
    scan_id = macro.getEnv("ScanID")

    if not isInMg( macro, detectorName):
        macro.output( "MsUtils.prepareDetectorAttrs: MG does not contain %s " % detectorName)
        return True
        
    tangoDevice_proxy = None
    count = 0
    while True:
        try:
            controllerProxy = _PyTango.DeviceProxy(detectorName)
            temp = controllerProxy.read_attribute( "TangoDevice").value 
            tangoDevice_proxy = _PyTango.DeviceProxy( temp)
            macro.debug("MsUtils.prepareDetectorAttrs: %s found in active MG" % detectorName)
            break
        except:
            count += 1
            if count > 5: 
                macro.output( "MsUtils.prepareDetectorAttrs: failed to create proxy to %s, %s" % (detectorName, controllerProxy.TangoDevice))
                macro.abort()
                return False
            macro.output( "MsUtils.prepareDetectorAttrs: failed to create proxy to %s, %s, retry" % (detectorName, controllerProxy.TangoDevice))

    #
    # ScanName, e.g.: au_012345
    #
    scanName = "%s_%05d" % (scan_file.split('.')[0], int( scan_id))
    fileDirName = None
    lst = ["FileDir", "SaveFilePath", "saving_directory"]
    for elm in lst:
        if hasattr( tangoDevice_proxy, elm):
            fileDirName = elm
            break
    else:
        macro.output( "MsUtils.prepareDetectorAttrs: attribute %s is missing on %s" % (str(lst), tangoDevice_proxy.name()))
        return False
    try:
        rootDirSrv = tangoDevice_proxy.read_attribute( fileDirName).value
    except Exception:
        macro.output( "MsUtils.prepareDetectorAttrs: caught exception during reading %s of %s" % (fileDirName, tangoDevice_proxy.name()))

    # 
    # see, if rootDir is compatible with the FileDir on the server
    # 
    if rootDirSrv.find( rootDir) != 0:
        macro.output( "MsUtils.prepareDetectorAttrs:")
        macro.output( "  %s: %s which is an attr of %s " % (fileDirName, rootDirSrv, tangoDevice_proxy.name()))
        macro.output( "    and")
        macro.output( "  rootDir: %s found in general_features" % (rootDir))
        macro.output( "    are incompatible")
        macro.output( "  Please fix it, maybe by changing the %s attribute in the detecter server" % fileDirName)
        macro.abort()
        return False

    #
    # it is important to create the directory before it is written to the server
    #
    fileDir = rootDir + "/" + scanName + "/" + detectorName
    macro.output( "MsUtils.prepareDetectorAttrs: creating %s (0o777)" % (fileDir))
    try:
        _os.makedirs( fileDir)
        _os.chmod( fileDir, 0o777)
    except Exception as e: 
        macro.output( e)
        macro.output( "MsUtils.prepareDetectorAttrs: failed to create %s" % fileDir)
        return False
    try:
        tangoDevice_proxy.write_attribute( fileDirName, fileDir)
    except Exception as e: 
        macro.output( "MsUtils.prepareDetectorAttrs: caught exception writing %s to %s, %s " % \
                      (fileDir, fileDirName,  tangoDevice_proxy.name()))
        macro.output( "%s" % ( repr(e)))
        return False

    set_nbframes = 1
    nbFramesName = None
    lst = ["NbFrames", "FrameNumbers", "acq_nb_frames"]
    for elm in lst:
        if hasattr( tangoDevice_proxy, elm):
            nbFramesName = elm
            break
    else:
        set_nbframes = 0

    if set_nbframes:
        try:
            tangoDevice_proxy.write_attribute( nbFramesName, nbFrames)
            macro.output( "MsUtils.prepareDetectorAttrs: Number of frames set to 1")
        except: 
            macro.output( "MsUtils.prepareDetectorAttrs: caught exception writing to %s, %s" % \
                          (nbFramesName, tangoDevice_proxy.name()))
            return False

    fileStartNum = None
    lst = ["FileStartNum", "saving_next_number", "FileIndex", "FileRefNumber"]
    for elm in lst:
        if hasattr( tangoDevice_proxy, elm):
            fileStartNum = elm
            break
    else:
        macro.output( "MsUtils.prepareDetectorAttrs: attribute %s is missing on %s" % (str(lst), tangoDevice_proxy.name()))
        return False

    try:
        #
        # P03, Jannik Woehnert: pscamera: FileRefNumber ist ein string
        #
        cfg = tangoDevice_proxy.get_attribute_config( fileStartNum)
        if cfg.data_type == _PyTango.CmdArgType.DevString:
            tangoDevice_proxy.write_attribute( fileStartNum, "0")
        else:
            tangoDevice_proxy.write_attribute( fileStartNum, 0)
    except: 
        macro.output( "MsUtils.prepareDetectorAttrs: caught exception writing to %s, %s" % \
                      (fileStartNum, tangoDevice_proxy.name()))
        return False

    filePrefix = None
    lst = ["FilePrefix", "saving_prefix"] 
    for elm in lst:
        if hasattr( tangoDevice_proxy, elm):
            filePrefix = elm
            #
            # Lima does not provide the '_' between prefix and image number itself
            #
            if elm == "saving_prefix":
                scanName += "_"
            break
    else:
        macro.output( "MsUtils.prepareDetectorAttrs: attribute %s is missing on %s" % ( str(lst), tangoDevice_proxy.name()))
        return False

    try:
        tangoDevice_proxy.write_attribute( filePrefix, scanName)
    except:                    
        macro.output( "MsUtils.prepareDetectorAttrs: failed to set %s %s, %s" % (filePrefix, detectorName, scanName))
        return False
    return True

def resetDetectorAttrs( macro, name = "pilatus", rootDir = "/ramdisk"):
    '''
      resetDetectorAttrs() is intended to be use in post-scan hooks to
      store imgages created by the 'ct' command in rootDir

        FileDir|SaveFilePath|saving_directory: to <rootDir>

     So far Pilatus and Lambda servers are supported
    '''
    detectorName = name

    if not isInMg( macro, detectorName):
        macro.output( "MsUtils.resetDetectorAttrs: MG does not contain %s" % detectorName)
        return True

    tangoDevice_proxy = None

    count = 0
    while True:
        try:
            controllerProxy = _PyTango.DeviceProxy(detectorName)
            temp = controllerProxy.read_attribute( "TangoDevice").value 
            tangoDevice_proxy = _PyTango.DeviceProxy( temp)
            macro.debug("MsUtils.resetDetectorAttrs: %s found in active MG" % detectorName)
            break
        except:
            count += 1
            if count > 5: 
                macro.output( "MsUtils.resetDetectorAttrs: failed to create proxy to %s, %s" % (detectorName, controllerProxy.TangoDevice))
                macro.abort()
                return False
            macro.output( "MsUtils.resetDetectorAttrs: failed to create proxy to %s, %s, retry" % (detectorName, controllerProxy.TangoDevice))

    fileDirName = None
    lst = ["FileDir", "SaveFilePath", "saving_directory"]
    for elm in lst:
        if hasattr( tangoDevice_proxy, elm):
            fileDirName = elm
            break
    else:
        macro.output( "MsUtils.resetDetectorAttrs: attribute %s is missing on %s" % (str(lst), tangoDevice_proxy.name()))
        return False

    try:
        rootDirSrv = tangoDevice_proxy.read_attribute( fileDirName).value
    except Exception:
        macro.output( "MsUtils.resetDetectorAttrs: caught exception during reading FileDir of %s" % tangoDevice_proxy.name())

    try:
        tangoDevice_proxy.write_attribute( fileDirName, rootDir)
    except Exception as e: 
        macro.output( "MsUtils.resetDetectorAttrs: caught exception writing %s to %s, %s " % \
                      (fileDir, fileDirName,  tangoDevice_proxy.name()))
        macro.output( "%s" % ( repr(e)))
        return False

    return True

def isInMg( macro, detectorName):
    '''
    getObj() disables Ctrl-Cs
    '''
    import sardana.macroserver.macro as _ms
    _ms.Type = TgUtils.TypeNames()

    active_mg = macro.getEnv("ActiveMntGrp")
    try:
        mg = macro.getObj(active_mg, type_class=_ms.Type.MeasurementGroup)
    except Exception as e:
        macro.output( "MsUtils.isInMg: getObj active_mg exception %s, aborting" % e)
        macro.abort()
        return False

    channels = mg.getChannelLabels()
    if detectorName in channels:
            return True
    return False

def isInMgWOgetObj( macro, detectorName):
    '''
    returns True, if detectorName in in the ActiveMntGrp
    '''
    active_mg = macro.getEnv("ActiveMntGrp")
    try:
        mg = _PyTango.DeviceProxy( active_mg)
    except Exception as e:
        macro.output( "MsUtils.isInMg: failed to create a proxy to %s,  %s, aborting" % (active_mg, e))
        macro.abort()
        return False
    channels = mg.read_attribute( "ElementList").value
    if detectorName in channels:
            return True
    return False

def testImport( filename):
    '''
    returns (True, ""), if filename can be imported
    returns (False, "exception-string") otherwise
    '''
    status = True
    msg = ""
    pathName = None
    macro_lib = None
    mfile = None
    lst = filename.rsplit( "/", 1)
    if len(lst) == 1:
        pathName = ""
        macro_lib = lst[0]
    elif len(lst) == 2:
        pathName = lst[0]
        macro_lib = lst[1]
    else:
        return (False, "something is wrong with %s" % filename)

    if macro_lib.find( ".py") > 0:
        macro_lib = macro_lib.split('.')[0]

    _sys.path.insert( 0, ".")
    try:
        mfile, pathname, desc = _imp.find_module( macro_lib, [pathName])
        m = _imp.load_module(macro_lib, mfile, pathname, desc)
        print( "imported %s --> OK" % (pathName))
    except Exception as e:
        #(eType, value, tracebackObject) = _sys.exc_info()
        status = False
        msg = repr( e)
    finally:
        if mfile is not None:
            mfile.close()

    return (status, msg)

#
# ===
#
def _appendAbs( scanInfo, mot, start, stop, intervals = None): 
    '''
    function to append absolute scans to the scanInfo
    ascan exp_dmy01 0 10 10 0.1

    extend the motor array of scanInfo by an entry of the kind
    { name:  someName, 
      start: the start of the scan
      stop:  the stop of the scan
    }
    '''
    mDct = {}
    mDct['name'] = mot
    mDct['start'] = float( start)
    mDct['stop'] = float( stop)
    if intervals is not None:
        mDct['intervals'] = int( intervals)
    scanInfo[ 'motors'].append( mDct)
    return
#
# ===
#
def _appendRel( scanInfo, mot, left, right, intervals = None): 
    '''
    function to append relative scans to the scanInfo
    dscan exp_dmy01 -1 1 10 0.1

    extend the motor array of scanInfo by an entry of the kind
    { name:  someName, 
      start: the start of the scan
      stop:  the stop of the scan
    }
    '''
    mDct = {}
    mDct['name'] = mot
    try:
        p = _PyTango.DeviceProxy( mDct[ 'name'])
    except Exception as e:
        print( "MsUtils._appendRel: failed to create proxy to %s" % mDct['name'])
    mDct['start'] = p.position + float( left)
    mDct['stop'] = p.position + float( right)
    if intervals is not None:
        mDct['intervals'] = int( intervals)
    scanInfo[ 'motors'].append( mDct)
    return

def getScanFileName(): 
    '''
    returns the file name used by the last scan
    returns None, if the file does not exist

    uses the MacroServer environment variables: ScanDir, ScanFilem ScanID
    '''
    scanDir = TgUtils.getEnv( "ScanDir") 
    scanFile = TgUtils.getEnv( "ScanFile") 
    scanID = TgUtils.getEnv( "ScanID") 
    
    if type( scanFile) is list: 
        scanFileTemp = scanFile[0]
    else: 
        scanFileTemp = scanFile
    #
    # ['tst.fio'] -> ['tst', 'fio'] 
    #
    lst = scanFileTemp.split( ".")

    fileName = "%s/%s_%05d.%s" % ( scanDir, lst[0], int( scanID), lst[1])

    if not _os.path.exists( fileName): 
        argout = None
    else: 
        argout = fileName

    return fileName
   
#
# ===
#
def createScanInfo( title = None):
    '''
    Depending on whether createScanInfo() is called in an after-scan-scenario or
    a pre-scan-scenario the title has to be supplied or not.

    title == None (after-scan-scenario): the function takes the title from ScanHistory 
             returns None, if ScanID != serialno (history), probably because
             the last scan has been aborted (ctrl-c)

    title != None (pre-scan-scenario): if ScanHistory is not valid because createScanInfo() 
             is called from a hook, the title has to be supplied.

             pre_scan_hook example: 
               scanInfo = HasyUtils.createScanInfo( self.getParentMacro().getCommand())

    returns a data structure describing the scan, see below, used e.g. mvsa and CursorApp
    {    
      motors: [{'start': 1.0, 'stop': 1.1, 'name': 'e6cctrl_h', 'proxy': PseudoMotor(pm/e6cctrl/1)}, 
      {'start': 0.0, 'stop': 0.1, 'name': 'e6cctrl_k'}, 
      {'start': 0.1, 'stop': 0.2, 'name': 'e6cctrl_l'}],
      serialno: 1238,
      title: 'hklscan 1.0 1.1 0.0 0.1 0.1 0.2 20 0.1',
    }
    or
    {
      motors: [{'start': 0.0, 'stop': 1.0, 'name': 'exp_dmy01'}, 
      {'start': 1.0, 'stop': 2.0, 'name': 'exp_dmy02'}, 
      {'start': 2.0, 'stop': 3.0, 'name': 'exp_dmy03'}],
      serialno: 1239,
      title: 'a3scan exp_dmy01 0.0 1.0 exp_dmy02 1.0 2.0 exp_dmy03 2.0 3.0 20 0.1',
    }
   
    serialno is taken from the environment.
    '''
    env = TgUtils.getEnvDct()
    scanInfo = {}
    scanInfo[ 'motors'] = []
    #
    # 1. case: after a scan, ScanHistory can be used
    #
    if title is None:
        lastScan = env['ScanHistory'][-1]
        scanInfo[ 'serialno'] = lastScan['serialno']
        #
        # serialno is from ScanHistory which is created after the scan completed successfully
        # ScanID is updated when a scan starts. ScanID != sericalno may be an indication
        # that the last scan has been ctrl-c'ed
        #
        if TgUtils.getEnv( "ScanID") != scanInfo['serialno']:
            return None
        scanInfo[ 'title'] = lastScan['title']
    #
    # 2. case: from e.g. a hook
    #
    else:
        if type( title) is str:
            scanInfo[ 'title'] = title
            scanInfo[ 'serialno'] = env['ScanID']
        else:
            return None

    _scanTitleToScanInfo( scanInfo[ 'title'], scanInfo)
    
    # TgUtils.dct_print( scanInfo)
    return scanInfo
#
#
#
def _scanTitleToScanInfo( title, scanInfo):
        
    lst = title.split()
    #
    # ascan exp_dmy01 0 1 10 0.1
    #
    if lst[0] == 'ascan':
        _appendAbs( scanInfo, lst[1], lst[2], lst[3])
        scanInfo[ 'intervals'] = int( lst[4])
        scanInfo[ 'sampleTime'] = float( lst[5])
    #
    # a2scan exp_dmy01 0 1 exp_dmy02 0 2 10 0.1
    #
    if lst[0] == 'a2scan':
        _appendAbs( scanInfo, lst[1], lst[2], lst[3])
        _appendAbs( scanInfo, lst[4], lst[5], lst[6])
        scanInfo[ 'intervals'] = int( lst[7])
        scanInfo[ 'sampleTime'] = float( lst[8])
    #
    # a3scan exp_dmy01 0 1 exp_dmy02 0 2 ... 10 0.1
    #
    if lst[0] == 'a3scan':
        _appendAbs( scanInfo, lst[1], lst[2], lst[3])
        _appendAbs( scanInfo, lst[4], lst[5], lst[6])
        _appendAbs( scanInfo, lst[7], lst[8], lst[9])
        scanInfo[ 'intervals'] = int( lst[10])
        scanInfo[ 'sampleTime'] = float( lst[11])

    #
    # hscan 1.0 1.1 20 0.1
    #
    if lst[0] == 'hscan':
        if TgUtils.isDevice( 'e6cctrl_h'):
            _appendAbs( scanInfo, 'e6cctrl_h', lst[1], lst[2])
        elif TgUtils.isDevice( 'kozhue6cctrl_h'):
            _appendAbs( scanInfo, 'kozhue6cctrl_h', lst[1], lst[2])
        scanInfo[ 'intervals'] = int( lst[3])
        scanInfo[ 'sampleTime'] = float( lst[4])
    if lst[0] == 'kscan':
        if TgUtils.isDevice( 'e6cctrl_k'):
            _appendAbs( scanInfo, 'e6cctrl_k', lst[1], lst[2])
        elif TgUtils.isDevice( 'kozhue6cctrl_k'):
            _appendAbs( scanInfo, 'kozhue6cctrl_k', lst[1], lst[2])
        scanInfo[ 'intervals'] = int( lst[3])
        scanInfo[ 'sampleTime'] = float( lst[4])
    if lst[0] == 'lscan':
        if TgUtils.isDevice( 'e6cctrl_l'):
            _appendAbs( scanInfo, 'e6cctrl_l', lst[1], lst[2])
        elif TgUtils.isDevice( 'kozhue6cctrl_l'):
            _appendAbs( scanInfo, 'kozhue6cctrl_l', lst[1], lst[2])
        scanInfo[ 'intervals'] = int( lst[3])
        scanInfo[ 'sampleTime'] = float( lst[4])

    if lst[0] == 'hklscan':
        diffH = _math.fabs( float( lst[2]) - float( lst[1]))
        diffK = _math.fabs( float( lst[4]) - float( lst[3]))
        diffL = _math.fabs( float( lst[6]) - float( lst[5]))
        if diffH > diffK and diffH > diffL:
            if TgUtils.isDevice( 'e6cctrl_h'):
                _appendAbs( scanInfo, 'e6cctrl_h', lst[1], lst[2])
            elif TgUtils.isDevice( 'kozhue6cctrl_h'):
                _appendAbs( scanInfo, 'kozhue6cctrl_h', lst[1], lst[2])
            if TgUtils.isDevice( 'e6cctrl_k'):
                _appendAbs( scanInfo, 'e6cctrl_k', lst[3], lst[4])
            elif TgUtils.isDevice( 'kozhue6cctrl_k'):
                _appendAbs( scanInfo, 'kozhue6cctrl_k', lst[3], lst[4])
            if TgUtils.isDevice( 'e6cctrl_l'):
                _appendAbs( scanInfo, 'e6cctrl_l', lst[5], lst[6])
            elif TgUtils.isDevice( 'kozhue6cctrl_l'):
                _appendAbs( scanInfo, 'kozhue6cctrl_l', lst[5], lst[6])
        elif diffK > diffH and diffK > diffL:
            if TgUtils.isDevice( 'e6cctrl_k'):
                _appendAbs( scanInfo, 'e6cctrl_k', lst[3], lst[4])
            elif TgUtils.isDevice( 'kozhue6cctrl_k'):
                _appendAbs( scanInfo, 'kozhue6cctrl_k', lst[3], lst[4])
            if TgUtils.isDevice( 'e6cctrl_h'):
                _appendAbs( scanInfo, 'e6cctrl_h', lst[1], lst[2])
            elif TgUtils.isDevice( 'kozhue6cctrl_h'):
                _appendAbs( scanInfo, 'kozhue6cctrl_h', lst[1], lst[2])
            if TgUtils.isDevice( 'e6cctrl_l'):
                _appendAbs( scanInfo, 'e6cctrl_l', lst[5], lst[6])
            elif TgUtils.isDevice( 'kozhue6cctrl_l'):
                _appendAbs( scanInfo, 'kozhue6cctrl_l', lst[5], lst[6])
        elif diffL > diffH and diffL > diffK:
            if TgUtils.isDevice( 'e6cctrl_l'):
                _appendAbs( scanInfo, 'e6cctrl_l', lst[5], lst[6])
            elif TgUtils.isDevice( 'kozhue6cctrl_l'):
                _appendAbs( scanInfo, 'kozhue6cctrl_l', lst[5], lst[6])
            if TgUtils.isDevice( 'e6cctrl_h'):
                _appendAbs( scanInfo, 'e6cctrl_h', lst[1], lst[2])
            elif TgUtils.isDevice( 'kozhue6cctrl_h'):
                _appendAbs( scanInfo, 'kozhue6cctrl_h', lst[1], lst[2])
            if TgUtils.isDevice( 'e6cctrl_k'):
                _appendAbs( scanInfo, 'e6cctrl_k', lst[3], lst[4])
            elif TgUtils.isDevice( 'kozhue6cctrl_k'):
                _appendAbs( scanInfo, 'kozhue6cctrl_k', lst[3], lst[4])
        elif diffH > 0.:
            if TgUtils.isDevice( 'e6cctrl_h'):
                _appendAbs( scanInfo, 'e6cctrl_h', lst[1], lst[2])
            elif TgUtils.isDevice( 'kozhue6cctrl_h'):
                _appendAbs( scanInfo, 'kozhue6cctrl_h', lst[1], lst[2])
            if TgUtils.isDevice( 'e6cctrl_k'):
                _appendAbs( scanInfo, 'e6cctrl_k', lst[3], lst[4])
            elif TgUtils.isDevice( 'kozhue6cctrl_k'):
                _appendAbs( scanInfo, 'kozhue6cctrl_k', lst[3], lst[4])
            if TgUtils.isDevice( 'e6cctrl_l'):
                _appendAbs( scanInfo, 'e6cctrl_l', lst[5], lst[6])
            elif TgUtils.isDevice( 'kozhue6cctrl_l'):
                _appendAbs( scanInfo, 'kozhue6cctrl_l', lst[5], lst[6])
        elif diffK > 0.:
            if TgUtils.isDevice( 'e6cctrl_k'):
                _appendAbs( scanInfo, 'e6cctrl_k', lst[3], lst[4])
            elif TgUtils.isDevice( 'kozhue6cctrl_k'):
                _appendAbs( scanInfo, 'kozhue6cctrl_k', lst[3], lst[4])
            if TgUtils.isDevice( 'e6cctrl_h'):
                _appendAbs( scanInfo, 'e6cctrl_h', lst[1], lst[2])
            elif TgUtils.isDevice( 'kozhue6cctrl_h'):
                _appendAbs( scanInfo, 'kozhue6cctrl_h', lst[1], lst[2])
            if TgUtils.isDevice( 'e6cctrl_l'):
                _appendAbs( scanInfo, 'e6cctrl_l', lst[5], lst[6])
            elif TgUtils.isDevice( 'kozhue6cctrl_l'):
                _appendAbs( scanInfo, 'kozhue6cctrl_l', lst[5], lst[6])
        else:
            if TgUtils.isDevice( 'e6cctrl_l'):
                _appendAbs( scanInfo, 'e6cctrl_l', lst[5], lst[6])
            elif TgUtils.isDevice( 'kozhue6cctrl_l'):
                _appendAbs( scanInfo, 'kozhue6cctrl_l', lst[5], lst[6])
            if TgUtils.isDevice( 'e6cctrl_h'):
                _appendAbs( scanInfo, 'e6cctrl_h', lst[1], lst[2])
            elif TgUtils.isDevice( 'kozhue6cctrl_h'):
                _appendAbs( scanInfo, 'kozhue6cctrl_h', lst[1], lst[2])
            if TgUtils.isDevice( 'e6cctrl_k'):
                _appendAbs( scanInfo, 'e6cctrl_k', lst[3], lst[4])
            elif TgUtils.isDevice( 'kozhue6cctrl_k'):
                _appendAbs( scanInfo, 'kozhue6cctrl_k', lst[3], lst[4])
        scanInfo[ 'intervals'] = int( lst[7])
        scanInfo[ 'sampleTime'] = float( lst[8])
    #
    # dscan exp_dmy01 -1 1 10 0.1
    #
    if lst[0] == 'dscan':
        _appendRel( scanInfo, lst[1], lst[2], lst[3])
        scanInfo[ 'intervals'] = int( lst[4])
        scanInfo[ 'sampleTime'] = float( lst[5])
    #
    # d2scan exp_dmy01 0 1 exp_dmy02 0 2 10 0.1
    #
    if lst[0] == 'd2scan':
        _appendRel( scanInfo, lst[1], lst[2], lst[3])
        _appendRel( scanInfo, lst[4], lst[5], lst[6])
        scanInfo[ 'intervals'] = int( lst[7])
        scanInfo[ 'sampleTime'] = float( lst[8])
    #
    # d3scan exp_dmy01 0 1 exp_dmy02 0 2 ... 10 0.1
    #
    if lst[0] == 'd3scan':
        _appendRel( scanInfo, lst[1], lst[2], lst[3])
        _appendRel( scanInfo, lst[4], lst[5], lst[6])
        _appendRel( scanInfo, lst[7], lst[8], lst[9])
        scanInfo[ 'intervals'] = int( lst[10])
        scanInfo[ 'sampleTime'] = float( lst[11])

    #
    # mesh exp_dmy01 0 1 10 exp_dmy02 1 2 12 0.1
    #
    if lst[0] == 'mesh':
        _appendAbs( scanInfo, lst[1], lst[2], lst[3], lst[4])
        _appendAbs( scanInfo, lst[5], lst[6], lst[7], lst[8])
        scanInfo[ 'sampleTime'] = float( lst[9])
        
    return
#
# ===
#
def dataRecordToScanInfo( dataRecord):
    '''
    creates the scanInfo dictionary from the  first dataRecord

    scanInfo: 
      {'title': u'ascan exp_dmy01 0.0 0.1 10 0.1', 
      'serialno': 1775, 
      'motors': [{'start': 0.0, 'stop': 0.1, 'name': u'exp_dmy01', 'proxy': Motor(motor/dummy_mot_ctrl/1)}], 
      'scanfile': [u'tst.fio', u'tst.nxs'],
      'filename': [u'tst_01780.fio', u'tst_01780.nxs'],
      'starttime': u'Thu Oct 13 15:35:48 2016', 
      'scandir': u'/home/kracht/Misc/IVP/temp'}
    '''
    scanInfo = {}
    scanInfo['scanfile'] = dataRecord[1]['data'][ 'scanfile']
    if scanInfo['scanfile'] is None:
        raise Exception( "MsUtils.dataRecordToScanInfo", "scanfile not defined")
    scanInfo['scandir'] = dataRecord[1]['data'][ 'scandir']
    if scanInfo['scandir'] is None:
        raise Exception( "MsUtils.dataRecordToScanInfo", "scandir not defined")
    scanInfo['serialno'] = dataRecord[1]['data'][ 'serialno']

    scanInfo['filename'] = []
    if type(scanInfo['scanfile']) is list:
        for sf in scanInfo['scanfile']:
            tpl = sf.rpartition('.')
            scanInfo['filename'].append( "%s_%05d.%s" % (tpl[0], scanInfo['serialno'], tpl[2]))
    else:
        tpl = scanInfo['scanfile'].rpartition('.')
        scanInfo['filename'].append( "%s_%05d.%s" % (tpl[0], scanInfo['serialno'], tpl[2]))

    scanInfo['starttime'] = dataRecord[1]['data']['starttime']
    scanInfo['title'] = dataRecord[1]['data']['title']

    scanInfo[ 'motors'] = []
    _scanTitleToScanInfo( scanInfo[ 'title'], scanInfo)

    return scanInfo

